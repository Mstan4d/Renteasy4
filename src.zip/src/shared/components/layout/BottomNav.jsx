// src/shared/components/layout/BottomNav.jsx
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './BottomNav.css';
import { getProfileRoute } from '../../utils/profileNavigation';
/**
 * BottomNav - Fixed bottom navigation bar for mobile devices
 * 
 * Features:
 * - Positioned fixed at bottom for easy thumb access
 * - Visual feedback for active page
 * - Special styling for primary action button (Post)
 * - Role-based navigation item visibility
 * - Authentication-aware display (hides when not logged in)
 * - Haptic/visual feedback on interaction
 * 
 * Design Principles:
 * - Follows Material Design bottom navigation guidelines
 * - Accessible with proper ARIA labels
 * - Responsive across all mobile screen sizes
 * - Consistent with RentEasy brand colors
 */
const BottomNav = () => {
  /**
   * useNavigate - React Router hook for programmatic navigation
   * Enables button clicks to change routes without full page reload
   */
  const navigate = useNavigate();
  
  /**
   * useLocation - React Router hook to access current route
   * Used to determine active state for visual feedback
   */
  const location = useLocation();
  
  /**
   * useAuth - Custom hook to access authentication context
   * Used to conditionally show/hide navigation items based on login status
   */
  const { isAuthenticated, user } = useAuth();
  
  /**
   * isActive - Helper function to determine if a route is currently active
   * Used to apply active styling to the current page's button
   * 
   * @param {string} path - The route path to check
   * @returns {boolean} True if the current location matches the path
   */
  const isActive = (path) => {
    // Special handling for dashboard to include root path
    if (path === '/dashboard') {
      return location.pathname.startsWith('/dashboard') || location.pathname === '/';
    }
    // Exact match or subpath match
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };
  
  /**
   * NAV_ITEMS - Configuration array for all navigation items
   * 
   * Each item contains:
   * - id: Unique identifier for the item
   * - path: Route path for navigation
   * - icon: Emoji or icon to display
   * - label: Accessible label for screen readers
   * - requiresAuth: Whether user must be logged in to see this item
   * - roles: Array of allowed user roles (empty means all roles)
   * - isPrimary: Special styling for important actions (like Post)
   * - description: Human-readable description for tooltips
   */
  const NAV_ITEMS = [
    {
      id: 'home',
      path: '/',
      icon: '🏠',
      label: 'Home',
      requiresAuth: false,
      roles: [],
      isPrimary: false,
      description: 'Return to homepage'
    },
    {
      id: 'search',
      path: '/listings',
      icon: '🔍',
      label: 'Search',
      requiresAuth: false,
      roles: [],
      isPrimary: false,
      description: 'Search properties'
    },
    {
      id: 'post',
      path: '/dashboard/post-property',
      icon: '➕',
      label: 'Post Listing',
      requiresAuth: true,
      roles: ['landlord', 'manager', 'tenant', 'estate-firm'],
      isPrimary: true,
      description: 'Create new property listing'
    },
    {
      id: 'services',
      path: '/services',
      icon: '🛠️',
      label: 'Services',
      requiresAuth: false,
      roles: [],
      isPrimary: false,
      description: 'Service providers directory'
    },
    {
      id: 'dashboard',
      path: '/dashboard',
      icon: '📊',
      label: 'Dashboard',
      requiresAuth: true,
      roles: ['tenant', 'landlord', 'manager', 'provider', 'estate-firm', 'admin'],
      isPrimary: false,
      description: 'Your personal dashboard'
    }
  ];

  /**
   * Conditional profile item configuration
   * Shows user avatar if available, otherwise defaults to profile emoji
   * This provides a personalized touch for authenticated users
   */
  const profileItem = {
    id: 'profile',
    path: '/dashboard/profile', // Use the dynamic route
    icon: user?.avatar ? () => (
      <div className="user-avatar-nav">
        <img src={user.avatar} alt={user.name} />
      </div>
    ) : '👤',
    label: 'Profile',
    requiresAuth: true,
    roles: ['tenant', 'landlord', 'manager', 'provider', 'estate-firm', 'admin'],
    isPrimary: false,
    description: 'Your account profile'
  };

  /**
   * Add profile item to navigation only if user is authenticated
   * This follows the principle of progressive disclosure
   */
  if (isAuthenticated) {
    NAV_ITEMS.push(profileItem);
  }
  
  /**
   * handleNavigation - Click handler for navigation buttons
   * Performs validation and navigation with visual feedback
   * 
   * Key validation steps:
   * 1. Check authentication requirements
   * 2. Validate role-based permissions
   * 3. Provide user feedback for restricted access
   * 4. Execute navigation if all checks pass
   * 
   * @param {Object} item - The navigation item being clicked
   */
  const handleNavigation = (item) => {
    // For dynamic paths, we need to calculate the actual path
    let actualPath = item.path;
    if (typeof item.path === 'function') {
      actualPath = item.path();
    }
    
    
    // Check role-based permissions
    if (item.roles.length > 0 && user && !item.roles.includes(user.role)) {
      alert(`This feature is only available for: ${item.roles.join(', ')}`);
      return;
    }
    
    // Perform navigation
    navigate(item.path);
  };
  
  /**
   * shouldShowItem - Determines if a navigation item should be displayed
   * Based on authentication status and user role
   * 
   * Display logic hierarchy:
   * 1. Public items (no auth required) - Always shown
   * 2. Auth-required items - Shown only when authenticated
   * 3. Role-restricted items - Shown only when user has appropriate role
   * 
   * @param {Object} item - Navigation item to check
   * @returns {boolean} True if item should be shown
   */
  const shouldShowItem = (item) => {
    // Public items are always shown
    if (!item.requiresAuth) return true;
    
    // If auth required but user not logged in, hide item
    if (!isAuthenticated) return false;
    
    // If no role restrictions, show to all authenticated users
    if (item.roles.length === 0) return true;
    
    // Check if user's role is allowed
    return item.roles.includes(user?.role);
  };
  
  /**
   * getFilteredNavItems - Filters navigation items based on user state
   * Creates a personalized navigation experience based on:
   * - Authentication status
   * - User role
   * - Available features
   * 
   * @returns {Array} Filtered array of navigation items to display
   */
  const getFilteredNavItems = () => {
    return NAV_ITEMS.filter(shouldShowItem);
  };
  
  /**
   * Responsive design consideration:
   * Bottom navigation is primarily for mobile devices
   * On desktop screens (width > 768px), alternative navigation is provided
   * This prevents duplication of navigation elements
   */
  if (window.innerWidth > 768) {
    return null;
  }
  
  return (
    /**
     * Bottom Navigation Container
     * 
     * Accessibility features:
     * - role="navigation": Indicates this is a navigation landmark
     * - aria-label: Describes the purpose for screen readers
     * - Ensures keyboard navigability through button elements
     * 
     * Visual design:
     * - Fixed positioning at bottom of viewport
     * - Consistent height and spacing
     * - Clear visual hierarchy with primary action standout
     * - Smooth transitions for interactive states
     */
    <nav 
      className="bottom-nav" 
      role="navigation"
      aria-label="Main navigation"
    >
      {getFilteredNavItems().map((item) => {
        const active = isActive(item.path);
        
        return (
          /**
           * Navigation Button
           * 
           * Key attributes for accessibility:
           * - key: Unique identifier for React rendering optimization
           * - className: Dynamic classes for styling states (active, primary)
           * - onClick: Navigation handler with validation
           * - title: Tooltip on hover for clarity
           * - aria-label: Accessible label combining icon meaning and state
           * - aria-current: Indicates current page for screen readers
           * - type="button": Explicit button type for form compatibility
           * 
           * Visual feedback:
           * - Active state indicator (bottom border)
           * - Hover and focus states
           * - Primary action standout styling
           */
          <button
            key={item.id}
            className={`nav-btn ${active ? 'active' : ''} ${
              item.isPrimary ? 'primary-action' : ''
            }`}
            onClick={() => handleNavigation(item)}
            title={item.description}
            aria-label={`${item.label} ${active ? '(current page)' : ''}`}
            aria-current={active ? 'page' : undefined}
            type="button"
          >
            {/* 
             * Icon Display
             * - Uses emoji for quick recognition
             * - aria-hidden="true" since icon is decorative
             * - Supports both string emojis and React components
             */}
            <span className="nav-icon" aria-hidden="true">
              {typeof item.icon === 'string' ? (
                item.icon
              ) : (
                <item.icon />
              )}
            </span>
            
            {/* 
             * Label Display
             * - Visible text for clarity
             * - Screen reader accessible
             * - Concise but descriptive
             */}
            <span className="nav-label">{item.label}</span>
            
            {/* 
             * Active State Indicator
             * - Visual cue for current page
             * - Animated transition for smooth state changes
             * - Positioned under the icon for clear indication
             */}
            {active && <span className="active-indicator" />}
          </button>
        );
      })}
    </nav>
  );
};

export default BottomNav;