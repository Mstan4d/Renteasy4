// src/modules/marketplace/pages/MarketplacePage.jsx
import React, { useState, useEffect } from 'react'
import { useAuth } from '../../../shared/context/AuthContext'
import { Search, Filter, Star, MapPin, Clock, CheckCircle, Users, TrendingUp, Download } from 'lucide-react'
import ProviderCard from '../components/ProviderCard'
import FilterPanel from '../components/FilterPanel'
import StatsOverview from '../components/StatsOverview'
import ExportModal from '../components/ExportModal'
import { serviceCategories, serviceTags } from '../data/serviceCategories';
import './Marketplace.css'

/**
 * MarketplacePage - Professional Service Provider Discovery
 * 
 * Features:
 * - Advanced search & filtering system
 * - Grid/List/Map view options
 * - Provider health scores & ratings
 * - Analytics dashboard
 * - Export functionality
 * - Professional UI matching TenantDashboard quality
 */
const MarketplacePage = () => {
  // ================= STATE MANAGEMENT =================
  const [providers, setProviders] = useState([])
  const [filteredProviders, setFilteredProviders] = useState([])
  const [selectedProvider, setSelectedProvider] = useState(null)
  const [activeView, setActiveView] = useState('grid') // grid, list, map
  const [activeTab, setActiveTab] = useState('all') // all, property-managers, maintenance, cleaning, legal, financial
  const [isLoading, setIsLoading] = useState(true)
  const [showExportModal, setShowExportModal] = useState(false)
  
  // Search & Filter states
  const [searchTerm, setSearchTerm] = useState('')
  // Replace or update your filters state
const [filters, setFilters] = useState({
    state: '',
    lga: '',
    minRating: 4.0,
    verifiedOnly: true,
    priceRange: [0, 1000000],
    services: [],
    availability: 'all',
    // NEW: Add service-specific filters
    category: '', // Main category (skilled-trades, cleaning-services, etc.)
    serviceType: '', // Specific service (electrician, plumber, etc.)
    tags: [], // Array of tag IDs
    serviceArea: 'all', // residential, commercial, industrial, all
    availabilityFeatures: {
      emergency: false,
      weekends: false,
      '24-7': false
    },
    sortBy: 'toprated'
  });
  // Analytics states
  const [analytics, setAnalytics] = useState({
    totalProviders: 0,
    avgRating: 0,
    verifiedCount: 0,
    topServices: [],
    monthlyGrowth: 0
  })
  
  // ================= AUTH CONTEXT =================
  const { user } = useAuth()
  
  // ================= DATA FETCHING =================
  useEffect(() => {
    const loadMarketplaceData = async () => {
      setIsLoading(true)
      
      try {
        // Simulate API loading
        await new Promise(resolve => setTimeout(resolve, 800))
        
        // Load from localStorage (your existing structure)
        const storedManagers = JSON.parse(localStorage.getItem("managers")) || []
        const estateProperties = JSON.parse(localStorage.getItem("estateProperties")) || []
        
        // Merge and transform data
        const transformedProviders = transformProviders(storedManagers, estateProperties)
        setProviders(transformedProviders)
        setFilteredProviders(transformedProviders)
        
        // Calculate analytics
        calculateAnalytics(transformedProviders)
        
      } catch (error) {
        console.error('Error loading marketplace data:', error)
      } finally {
        setIsLoading(false)
      }
    }
    
    loadMarketplaceData()
  }, [])
  
  // ================= DATA TRANSFORMATION =================
  // Update the transformProviders function in your MarketplacePage.jsx
// In MarketplacePage.jsx, update the transformProviders function:
const transformProviders = () => {
  // Load from new provider system
  const serviceProviders = JSON.parse(localStorage.getItem('serviceProviders') || '[]');
  const providerServices = JSON.parse(localStorage.getItem('providerServices') || '[]');
  const reviews = JSON.parse(localStorage.getItem('providerReviews') || '[]');
  
  // Transform to match ProviderCard format
  return serviceProviders
    .filter(p => p.status === 'approved') // Only show approved providers
    .map(provider => {
      const providerServicesList = providerServices.filter(s => s.providerId === provider.userId);
      const providerReviews = reviews.filter(r => r.providerId === provider.id);
      
      // Calculate average rating
      const avgRating = providerReviews.length > 0 
        ? providerReviews.reduce((sum, r) => sum + r.rating, 0) / providerReviews.length
        : 4.0; // Default rating
      
      return {
        id: provider.id,
        userId: provider.userId,
        name: provider.ownerName || provider.businessName,
        company: provider.businessName,
        type: 'service-provider',
        tier: provider.verificationLevel === 'verified' ? 'Verified Firm' : 'Basic Provider',
        rating: parseFloat(avgRating.toFixed(1)),
        reviews: providerReviews.length,
        location: provider.coverage?.states?.join(', ') || provider.state || 'Nationwide',
        state: provider.state || '',
        lga: provider.city || '',
        services: providerServicesList.map(s => s.title),
        monthlyRate: 0, // You might want to add pricing later
        hourlyRate: 0,
        verified: provider.verificationLevel === 'verified',
        healthScore: calculateProviderHealthScore(provider),
        responseTime: provider.responseTime || 'Within 24 hours',
        description: provider.description || '',
        logo: provider.logo || '/images/provider-placeholder.png',
        contact: {
          phone: provider.phone,
          email: provider.email,
          website: provider.website
        },
        tags: provider.tags || [],
        stats: {
          propertiesManaged: 0, // Update if applicable
          yearsExperience: provider.yearsInBusiness || 1,
          successRate: 95
        },
        category: providerServicesList[0]?.category || 'other',
        serviceType: providerServicesList[0]?.title || 'General Services',
        availability: {
          emergency: provider.tags?.includes('emergency') || false,
          weekends: false,
          '24-7': provider.tags?.includes('24-7') || false
        },
        serviceArea: 'all'
      };
    });
};
  
  const calculateProviderHealthScore = (provider) => {
    let score = 50; // Base score
    
    // Add points for verification
    if (provider.verificationLevel === 'verified') score += 20;
    if (provider.isRegisteredBusiness) score += 10;
    
    // Add points for completeness
    if (provider.description?.length > 100) score += 5;
    if (provider.logo) score += 5;
    if (provider.portfolioImages?.length > 0) score += 5;
    if (provider.certifications?.length > 0) score += 5;
    
    return Math.min(100, score);
  };
  
  const generateTags = (provider) => {
    const tags = []
    if (provider.verified) tags.push('Verified')
    if (provider.rating >= 4.5) tags.push('Top Rated')
    if (provider.responseTime?.includes('1 hour')) tags.push('Fast Response')
    if (provider.services?.includes('24/7')) tags.push('24/7 Service')
    return tags
  }
  
  const calculateAnalytics = (providers) => {
    const total = providers.length
    const verifiedCount = providers.filter(p => p.verified).length
    const avgRating = providers.reduce((sum, p) => sum + p.rating, 0) / total || 0
    
    // Count services frequency
    const serviceCounts = {}
    providers.forEach(p => {
      p.services?.forEach(service => {
        serviceCounts[service] = (serviceCounts[service] || 0) + 1
      })
    })
    
    const topServices = Object.entries(serviceCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([service]) => service)
    
    setAnalytics({
      totalProviders: total,
      avgRating: parseFloat(avgRating.toFixed(1)),
      verifiedCount,
      topServices,
      monthlyGrowth: 12.5 // Mock growth
    })
  }
  
  // ================= FILTERING & SEARCH =================
 // In MarketplacePage.jsx, update the useEffect for filtering:
useEffect(() => {
  if (!providers.length) return;

  let filtered = providers;
  
  // Apply search term
  if (searchTerm.trim()) {
    const term = searchTerm.toLowerCase();
    filtered = filtered.filter(provider =>
      provider.name.toLowerCase().includes(term) ||
      provider.company.toLowerCase().includes(term) ||
      (provider.services && provider.services.some(service => 
        service.toLowerCase().includes(term)
      ))
    );
  }
  
  // Apply tab filter
  if (activeTab !== 'all') {
    filtered = filtered.filter(provider => {
      // Map your categories to tabs
      const categoryMap = {
        'property-manager': 'property-managers',
        'maintenance': 'maintenance-repair',
        'cleaning': 'cleaning-services'
      };
      return provider.category === categoryMap[activeTab];
    });
  }
  
  // Apply state filter
  if (filters.state) {
    filtered = filtered.filter(provider => {
      // Check both state and coverage states
      const stateMatch = provider.state === filters.state;
      const coverageMatch = provider.coverage?.states?.includes(filters.state);
      return stateMatch || coverageMatch;
    });
  }
  
  // Apply rating filter
  filtered = filtered.filter(provider => provider.rating >= filters.minRating);
  
  // Apply verification filter
  if (filters.verifiedOnly) {
    filtered = filtered.filter(provider => provider.verified);
  }
  
  // Apply service type filter
  if (filters.serviceType) {
    filtered = filtered.filter(provider => 
      provider.services && provider.services.some(service => 
        service.toLowerCase().includes(filters.serviceType.toLowerCase())
      )
    );
  }
  
  // Apply availability filters
  if (filters.availability) {
    if (filters.availability.emergency) {
      filtered = filtered.filter(provider => 
        provider.tags && provider.tags.includes('emergency')
      );
    }
    if (filters.availability.weekends) {
      filtered = filtered.filter(provider => 
        provider.availability?.weekends
      );
    }
    if (filters.availability['24-7']) {
      filtered = filtered.filter(provider => 
        provider.tags && provider.tags.includes('24-7')
      );
    }
  }
  
  // Apply sorting
  if (filters.sortBy) {
    filtered.sort((a, b) => {
      switch (filters.sortBy) {
        case 'toprated':
          return b.rating - a.rating;
        case 'newest':
          return new Date(b.createdAt || 0) - new Date(a.createdAt || 0);
        case 'name':
          return a.name.localeCompare(b.name);
        case 'healthscore':
          return b.healthScore - a.healthScore;
        default:
          return 0;
      }
    });
  }
  
       // In the filtering useEffect, add these checks after other filters:

// NEW: Category filter
if (filters.category) {
  filtered = filtered.filter(provider => 
    provider.category === filters.category
  );
}

// NEW: Service type filter
if (filters.serviceType) {
  filtered = filtered.filter(provider => 
    provider.serviceType === filters.serviceType
  );
}

// NEW: Tags filter
if (filters.tags && filters.tags.length > 0) {
  filtered = filtered.filter(provider => {
    if (!provider.tags) return false;
    return filters.tags.every(tag => provider.tags.includes(tag));
  });
}

// NEW: Service area filter
if (filters.serviceArea && filters.serviceArea !== 'all') {
  filtered = filtered.filter(provider => 
    provider.serviceArea === filters.serviceArea || 
    provider.tags?.includes(filters.serviceArea)
  );
}

// NEW: Availability features filter
if (filters.availabilityFeatures) {
  if (filters.availabilityFeatures.emergency) {
    filtered = filtered.filter(provider => 
      provider.availability?.emergency || 
      provider.tags?.includes('emergency')
    );
  }
  if (filters.availabilityFeatures.weekends) {
    filtered = filtered.filter(provider => 
      provider.availability?.weekends
    );
  }
  if (filters.availabilityFeatures['24-7']) {
    filtered = filtered.filter(provider => 
      provider.availability?.['24-7'] || 
      provider.tags?.includes('24-7')
    );
  }
}
      
    // Apply search term
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(provider =>
        provider.name.toLowerCase().includes(term) ||
        provider.company.toLowerCase().includes(term) ||
        provider.services.some(service => service.toLowerCase().includes(term))
      )
    }
    
    // Apply type filter
    if (activeTab !== 'all') {
      filtered = filtered.filter(provider => provider.type === activeTab)
    }
    
    // Apply state filter
    if (filters.state) {
      filtered = filtered.filter(provider => provider.state === filters.state)
    }
    
    // Apply LGA filter
    if (filters.lga) {
      filtered = filtered.filter(provider => provider.lga === filters.lga)
    }
    
    // Apply rating filter
    filtered = filtered.filter(provider => provider.rating >= filters.minRating)
    
    // Apply verification filter
    if (filters.verifiedOnly) {
      //filtered = filtered.filter(provider => provider.verified)
    }
    
    // Apply price filter
    filtered = filtered.filter(provider => {
      const price = provider.monthlyRate || provider.hourlyRate * 160 || 0
      return price >= filters.priceRange[0] && price <= filters.priceRange[1]
    })
    
    setFilteredProviders(filtered)
  }, [providers, searchTerm, activeTab, filters])
  
  // ================= EVENT HANDLERS =================
  
  const handleFilterChange = (newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }))
  }
  
  const handleExport = (format) => {
    // Export logic based on format (csv, pdf, excel)
    console.log(`Exporting ${filteredProviders.length} providers as ${format}`)
    // Your export implementation here
  }
  
  const handleContactProvider = (provider, method) => {
    // Store lead in localStorage (your existing logic)
    const lead = {
      id: Date.now(),
      providerId: provider.id,
      providerName: provider.name,
      contactedBy: user?.email || 'guest',
      method: method,
      timestamp: new Date().toISOString()
    }

    // Then update the button click handler:
const handleBecomeProvider = () => {
  const providerStatus = checkUserProviderStatus();
  
  if (!user) {
    navigate('/signup', { state: { role: 'service-provider' } });
  } else if (providerStatus.isProvider || providerStatus.hasProfile) {
    navigate('/dashboard/provider');
  } else {
    if (confirm('You need to register as a service provider. Create a provider profile now?')) {
      // Navigate to provider registration page
      navigate('/providers/register', { state: { userId: user.id } });
    }
  }
};

    const checkUserProviderStatus = () => {
      if (!user) return { isProvider: false, hasProfile: false };
      
      const providers = JSON.parse(localStorage.getItem('serviceProviders') || '[]');
      const userProvider = providers.find(p => p.userId === user.id || p.email === user.email);
      
      return {
        isProvider: user.role === 'service-provider',
        hasProfile: !!userProvider,
        providerData: userProvider
      };
    };
    
    const leads = JSON.parse(localStorage.getItem("firmLeads") || "[]")
    leads.push(lead)
    localStorage.setItem("firmLeads", JSON.stringify(leads))
    
    // Show success message
    alert(`${method === 'hire' ? 'Hire request' : 'Contact request'} sent to ${provider.name}!`)
  }
  
  // ================= RENDER LOADING STATE =================
  if (isLoading) {
    return (
      <div className="marketplace-loading">
        <div className="loading-spinner"></div>
        <p>Loading professional service providers...</p>
      </div>
    )
  }
  
  // ================= MAIN RENDER =================
  return (
    <div className="marketplace">
      {/* Header Section */}
      <header className="marketplace-header">
        <div className="header-content">
          <h1 className="page-title">
            Professional <span className="highlight">Services</span> Marketplace
          </h1>
          <p className="page-subtitle">
            Connect with verified estate firms, certified partners, and high-rated property managers across Nigeria
          </p>
        </div>
        
        <div className="header-actions">
          <button 
            className="btn btn-secondary"
            onClick={() => setShowExportModal(true)}
          >
            <Download size={18} />
            Export Results
          </button>
        </div>
      </header>
      
      {/* Analytics Overview */}
      <StatsOverview analytics={analytics} />
      
      {/* Main Content Area */}
      <div className="marketplace-content">
        {/* Left Sidebar - Filters */}
        <aside className="filters-sidebar">
          <div className="filters-header">
            <h3><Filter size={18} /> Filters</h3>
            <button 
              className="btn-text"
              onClick={() => setFilters({
                state: '',
                lga: '',
                minRating: 4.0,
                verifiedOnly: true,
                priceRange: [0, 1000000],
                services: [],
                availability: 'all'
              })}
            >
              Clear All
            </button>
          </div>
          
          <FilterPanel 
            filters={filters}
            onFilterChange={handleFilterChange}
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
          />
        </aside>
        
        {/* Main Content */}
        <main className="providers-main">
          {/* Tabs & View Controls */}
          <div className="content-controls">
            <div className="service-tabs">
              <button 
                className={`tab-btn ${activeTab === 'all' ? 'active' : ''}`}
                onClick={() => setActiveTab('all')}
              >
                All Services
              </button>
              <button 
                className={`tab-btn ${activeTab === 'property-manager' ? 'active' : ''}`}
                onClick={() => setActiveTab('property-manager')}
              >
                Property Managers
              </button>
              <button 
                className={`tab-btn ${activeTab === 'maintenance' ? 'active' : ''}`}
                onClick={() => setActiveTab('maintenance')}
              >
                Maintenance
              </button>
              <button 
                className={`tab-btn ${activeTab === 'cleaning' ? 'active' : ''}`}
                onClick={() => setActiveTab('cleaning')}
              >
                Cleaning
              </button>
            </div>
            
            <div className="view-controls">
              <span className="results-count">
                {filteredProviders.length} providers found
              </span>
              <div className="view-toggle">
                <button 
                  className={`view-btn ${activeView === 'grid' ? 'active' : ''}`}
                  onClick={() => setActiveView('grid')}
                  title="Grid View"
                >
                  ▦
                </button>
                <button 
                  className={`view-btn ${activeView === 'list' ? 'active' : ''}`}
                  onClick={() => setActiveView('list')}
                  title="List View"
                >
                  ≡
                </button>
              </div>
            </div>
          </div>
          
          {/* Providers Grid/List */}
          {filteredProviders.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">🔍</div>
              <h3>No service providers found</h3>
              <p>Try adjusting your search criteria or filters</p>
            </div>
          ) : (
            <div className={`providers-container ${activeView}-view`}>
              {filteredProviders.map(provider => (
                <ProviderCard
                  key={provider.id}
                  provider={provider}
                  viewMode={activeView}
                  onContact={(method) => handleContactProvider(provider, method)}
                  onViewDetails={() => setSelectedProvider(provider)}
                />
              ))}
            </div>
          )}
          
          {/* Quick Stats Footer */}
          <div className="quick-stats">
            <div className="stat-item">
              <span className="stat-icon">🏢</span>
              <div>
                <span className="stat-value">{analytics.verifiedCount}</span>
                <span className="stat-label">Verified Firms</span>
              </div>
            </div>
            <div className="stat-item">
              <span className="stat-icon">⭐</span>
              <div>
                <span className="stat-value">{analytics.avgRating}</span>
                <span className="stat-label">Avg. Rating</span>
              </div>
            </div>
            <div className="stat-item">
              <span className="stat-icon">📈</span>
              <div>
                <span className="stat-value">{analytics.monthlyGrowth}%</span>
                <span className="stat-label">Monthly Growth</span>
              </div>
            </div>
          </div>
        </main>
      </div>

      // In MarketplacePage.jsx, add a review CTA
<div className="review-cta">
  <h3>Share Your Experience</h3>
  <p>Help others make better decisions by sharing your reviews</p>
  <button 
    className="btn btn-primary"
    onClick={() => {
      // Logic to show review form for a provider you've hired
    }}
  >
    <Star size={18} />
    Write a Review
  </button>
</div>
      
      {/* Export Modal */}
      {showExportModal && (
        <ExportModal
          isOpen={showExportModal}
          onClose={() => setShowExportModal(false)}
          onExport={handleExport}
          dataCount={filteredProviders.length}
        />
      )}
      
      {/* Bottom Action Bar */}
      <div className="action-bar">
        <div className="commission-notice">
          <span className="notice-icon">💼</span>
          <span>RentEasy receives 2% commission on successful connections</span>
        </div>
        <div className="action-buttons">
          <button className="btn btn-secondary">Need Help?</button>
          <button className="btn btn-primary" onClick={handleBecomeProvider}>
  {!user ? 'Become a Provider' : 
   providerStatus.isProvider ? 'Go to Provider Dashboard' : 
   'Register as Provider'}
</button>
        </div>
      </div>
    </div>
  )
}

export default MarketplacePage