import React, { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../../../shared/context/AuthContext'
import Header from '../../../shared/components/Header'
import VerifiedBadge, { InlineVerifiedBadge } from '../../../shared/components/VerifiedBadge'
import { createNewListing } from '../../../shared/utils/listingUtils' // Remove if not used
import './Home.css'

const Home = () => {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [listings, setListings] = useState([])
  const [filteredListings, setFilteredListings] = useState([])
  const [searchParams, setSearchParams] = useState({
    location: '',
    price: '',
    state: '',
    lga: ''
  })

  // Enhanced mock listings data with verification status - KEEP THIS FOR DEMO
  const mockListings = [
    { 
      id: 'mock_1', 
      title: "2 Bedroom Flat in Lekki", 
      price: 1500000, 
      description: "Spacious · Gated estate", 
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=400", 
      location: "Lekki, Lagos", 
      state: "Lagos", 
      lga: "Lekki",
      userId: 'landlord_001',
      posterName: 'Verified Properties Ltd.',
      userVerified: true,
      verified: true,
      verificationLevel: 'premium',
      postedDate: '2024-12-10',
      amenities: ['24/7 Security', 'Swimming Pool', 'Gym']
    },
    { 
      id: 'mock_2', 
      title: "Self-contain in Garki", 
      price: 400000, 
      description: "Near market · Secure", 
      image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400", 
      location: "Garki, Abuja", 
      state: "Abuja", 
      lga: "Garki",
      userId: 'landlord_002',
      posterName: 'John Doe',
      userVerified: false,
      verified: false,
      status: 'pending',
      postedDate: '2024-12-12',
      amenities: ['Water Supply', '24/7 Electricity']
    },
    { 
      id: 'mock_3', 
      title: "3 Bedroom Duplex in Ikeja", 
      price: 3000000, 
      description: "Fully furnished · Parking", 
      image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400", 
      location: "Ikeja, Lagos", 
      state: "Lagos", 
      lga: "Ikeja",
      userId: 'landlord_003',
      posterName: 'Estate Masters',
      userVerified: true,
      verified: true,
      verificationLevel: 'estate',
      postedDate: '2024-12-11',
      amenities: ['Parking Space', 'Garden', 'Playground', 'CCTV']
    },
    { 
      id: 'mock_4', 
      title: "Studio Apartment in Victoria Island", 
      price: 1800000, 
      description: "Modern · Sea view · Fully serviced", 
      image: "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?w=400", 
      location: "Victoria Island, Lagos", 
      state: "Lagos", 
      lga: "Victoria Island",
      userId: 'landlord_004',
      posterName: 'Luxury Homes',
      userVerified: true,
      verified: true,
      verificationLevel: 'premium',
      postedDate: '2024-12-13',
      amenities: ['Sea View', 'Concierge', 'Smart Home']
    }
  ]

  useEffect(() => {
    // Load REAL listings from localStorage
    const savedListings = JSON.parse(localStorage.getItem('listings')) || []
    
    // Combine mock listings with real listings (real ones first, then mock)
    const allListings = [...savedListings, ...mockListings]
    
    // Remove duplicates by ID
    const uniqueListings = allListings.filter((listing, index, self) =>
      index === self.findIndex(l => l.id === listing.id)
    )
    
    // Shuffle the listings for random display
    const shuffledListings = [...uniqueListings].sort(() => Math.random() - 0.5)
    
    setListings(shuffledListings)
    setFilteredListings(shuffledListings.slice(0, 8)) // Show only 8 on homepage
  }, [])

  const handleSearch = (e) => {
    e.preventDefault()
    
    const { location, price } = searchParams
    const filtered = listings.filter(listing => {
      const matchesLocation = !location || 
        (listing.location && listing.location.toLowerCase().includes(location.toLowerCase())) ||
        (listing.title && listing.title.toLowerCase().includes(location.toLowerCase())) ||
        (listing.state && listing.state.toLowerCase().includes(location.toLowerCase())) ||
        (listing.lga && listing.lga.toLowerCase().includes(location.toLowerCase()))
      
      const matchesPrice = !price || (listing.price && listing.price <= parseInt(price))
      
      return matchesLocation && matchesPrice
    })
    
    setFilteredListings(filtered.slice(0, 8))
    document.getElementById('listings').scrollIntoView({ behavior: 'smooth' })
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setSearchParams(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const scrollToSearch = () => {
    document.getElementById('search').scrollIntoView({ behavior: 'smooth' })
  }

  const openMap = (location) => {
    const query = encodeURIComponent(location)
    window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank')
  }

  // FIXED: View Listing Details - navigate to listings page with state
  const viewListingDetails = (listing) => {
    // Save the selected listing to localStorage
    localStorage.setItem('currentListing', JSON.stringify(listing))
    
    // Navigate to listings page - it will read from localStorage
    navigate('/listings')
  }

  // Function to get verification badge type based on verification level
  const getVerificationType = (listing) => {
    if (listing.userRole === 'estate-firm') return 'estate'
    if (listing.verificationLevel === 'premium') return 'property'
    if (listing.userVerified && listing.userRole === 'landlord') return 'landlord'
    if (listing.userVerified && listing.userRole === 'tenant') return 'tenant'
    return 'user'
  }

  // Function to get listing status for display
  const getListingStatus = (listing) => {
    if (listing.rejected) return { text: 'Rejected', class: 'rejected' }
    if (listing.verified && listing.status === 'approved') return { text: 'Verified', class: 'verified' }
    if (listing.status === 'pending' || (!listing.verified && !listing.rejected)) return { text: 'Pending', class: 'pending' }
    return { text: 'Unknown', class: 'unknown' }
  }

  return (
    <>
      <Header />
      
      <main className="home-container">
        {/* Hero Section */}
        <section className="hero">
          <div className="hero-content">
            <h1 className="hero-title">Find Apartments Easily Without Agents</h1>
            <p className="hero-subtitle">
              Rent directly from outgoing tenants and verified landlords.
            </p>
            <button 
              onClick={scrollToSearch}
              className="hero-button"
            >
              Start Searching
            </button>
          </div>
        </section>

        {/* ===================== DEVELOPMENT TESTING SECTION ===================== */}
        {/* REMOVE THIS ENTIRE SECTION BEFORE HOSTING - FOR DEVELOPMENT ONLY */}
        <div className="dev-testing-section">
          <h3>🚀 Development Testing Panel</h3>
          <div className="dev-buttons">
            <button 
              onClick={() => navigate('/dashboard/estate')}
              className="dev-btn"
            >
              Estate Dashboard
            </button>
            
            <button 
              onClick={() => navigate('/verify')}
              className="dev-btn"
            >
              Get Verified
            </button>
            
            <button 
              onClick={() => navigate('/dashboard')}
              className="dev-btn"
            >
              User Dashboard
            </button>
            
            <button 
              onClick={() => navigate('/admin')}
              className="dev-btn admin-btn"
            >
              Admin Panel
            </button>
            
            <button 
              onClick={() => navigate('/dashboard/post-property')}
              className="dev-btn post-btn"
            >
              Post Property
            </button>
          </div>
          <p className="dev-user-info">
            {user ? `Logged in as: ${user.name} (${user.role})` : 'Not logged in'}
          </p>
          <div className="dev-stats">
            <span>Listings: {listings.length}</span>
            <span>Verified: {listings.filter(l => l.verified).length}</span>
            <span>Pending: {listings.filter(l => !l.verified && !l.rejected).length}</span>
          </div>
        </div>
        {/* ===================== END DEVELOPMENT SECTION ===================== */}

        {/* Enhanced Search Section */}
        <section className="search-section" id="search">
          <div className="search-header">
            <h2 className="search-title">Find Your Perfect Home</h2>
            <p className="search-subtitle">Search thousands of verified properties from direct landlords</p>
          </div>
          
          <form className="search-form" onSubmit={handleSearch}>
            <div className="form-row">
              <div className="form-group">
                <div className="input-icon">
                  📍
                </div>
                <input
                  type="text"
                  name="location"
                  value={searchParams.location}
                  onChange={handleInputChange}
                  placeholder="Enter city, state, or landmark..."
                  className="search-input"
                />
              </div>

              <div className="form-group">
                <div className="input-icon">
                  💰
                </div>
                <input
                  type="number"
                  name="price"
                  value={searchParams.price}
                  onChange={handleInputChange}
                  placeholder="Maximum budget"
                  className="search-input"
                />
              </div>

              <button type="submit" className="search-button">
                <span className="search-icon">🔍</span>
                Search Properties
              </button>
            </div>
            
            <div className="search-tips">
              <span className="tip">💡 Try: "Lagos" | "₦500,000" | "2 Bedroom"</span>
              <span className="tip">✅ Only verified landlords</span>
              <span className="tip">🏠 Direct from owners</span>
            </div>
          </form>
        </section>

        {/* Listings Section */}
        <section className="listings-section" id="listings">
          <div className="section-header">
            <div className="header-left">
              <h2 className="section-title">Latest Properties</h2>
              <p className="section-subtitle">Discover apartments posted by tenants and landlords directly</p>
            </div>
            <div className="filter-options">
              <button 
                className="filter-btn primary"
                onClick={() => {
                  const verifiedListings = listings.filter(listing => listing.verified)
                  setFilteredListings(verifiedListings.slice(0, 8))
                }}
              >
                ✅ Verified Only
              </button>
              <button 
                className="filter-btn"
                onClick={() => setFilteredListings(listings.slice(0, 8))}
              >
                🔄 Show All
              </button>
              <Link to="/listings" className="view-all-btn">
                View All Listings →
              </Link>
            </div>
          </div>
          
          <div className="listings-grid">
            {filteredListings.length > 0 ? (
              filteredListings.map((listing) => {
                const verificationType = getVerificationType(listing)
                const status = getListingStatus(listing)
                const isUserVerified = listing.userVerified
                const isPropertyVerified = listing.verified
                
                return (
                  <div key={listing.id} className={`property-card ${status.class}`}>
                    {/* Property Image */}
                    <div className="property-image-container">
                      <img 
                        src={listing.image || listing.images?.[0] || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=400'} 
                        alt={listing.title} 
                        className="property-image" 
                      />
                      
                      {/* Status Badge */}
                      <div className="property-status-badge">
                        <span className={`status-dot ${status.class}`}></span>
                        {status.text}
                      </div>
                      
                      {/* Verified Badge Overlay */}
                      {isUserVerified && (
                        <div className="property-verified-overlay">
                          <VerifiedBadge 
                            type={verificationType} 
                            size="small"
                            showTooltip={true}
                          />
                        </div>
                      )}
                      
                      {/* Premium Badge */}
                      {listing.verificationLevel === 'premium' && (
                        <div className="premium-badge">
                          👑 Premium
                        </div>
                      )}
                    </div>
                    
                    {/* Property Content */}
                    <div className="property-content">
                      <div className="property-header">
                        <h3>{listing.title}</h3>
                        {isUserVerified && (
                          <div className="property-verification-status">
                            <InlineVerifiedBadge type={verificationType} />
                          </div>
                        )}
                      </div>
                      
                      <p className="property-price">₦{listing.price?.toLocaleString() || '0'}</p>
                      <p className="property-desc">{listing.description}</p>
                      
                      {/* Verification Info */}
                      <div className="property-verification-info">
                        {isUserVerified && (
                          <span className="verification-detail verified">
                            <span className="verification-icon">✓</span>
                            Verified {listing.userRole || 'User'}
                          </span>
                        )}
                        
                        {!isUserVerified && (
                          <span className="verification-detail unverified">
                            <span className="verification-icon">⚠️</span>
                            Unverified
                          </span>
                        )}
                        
                        {isPropertyVerified && (
                          <span className="verification-detail property-verified">
                            <span className="verification-icon">🏠</span>
                            Property Verified
                          </span>
                        )}
                      </div>
                      
                      {/* Amenities */}
                      {listing.amenities && listing.amenities.length > 0 && (
                        <div className="property-amenities">
                          {listing.amenities.slice(0, 3).map((amenity, index) => (
                            <span key={index} className="amenity-tag">
                              {amenity}
                            </span>
                          ))}
                          {listing.amenities.length > 3 && (
                            <span className="amenity-tag">+{listing.amenities.length - 3} more</span>
                          )}
                        </div>
                      )}
                      
                      <p className="property-location">
                        <span className="location-icon">📍</span>
                        {listing.location || `${listing.lga}, ${listing.state}`}
                      </p>
                      
                      <div className="property-footer">
                        <div className="landlord-info">
                          <span className="landlord-name">
                            {listing.posterName || listing.landlordName || 'Unknown'}
                          </span>
                          <span className="posted-date">
                            {listing.postedDate || new Date(listing.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        
                        <div className="property-actions">
                          <button 
                            onClick={() => openMap(listing.location || `${listing.lga}, ${listing.state}`)}
                            className="map-button"
                          >
                            📍 Map
                          </button>
                          <button 
                            onClick={() => viewListingDetails(listing)}
                            className="details-button"
                          >
                            🔍 Details
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })
            ) : (
              <div className="no-results">
                <div className="no-results-icon">🏠</div>
                <p>No properties match your search</p>
                <button 
                  onClick={() => {
                    setFilteredListings(listings.slice(0, 8))
                    setSearchParams({ location: '', price: '', state: '', lga: '' })
                  }}
                  className="reset-search-btn"
                >
                  Reset Search
                </button>
              </div>
            )}
          </div>
        </section>

        {/* Promo Sections */}
        <section className="promo-section">
          <div className="promo-card manager-promo">
            <div className="promo-header">
              <h2>Hire a Verified Property Manager</h2>
              <VerifiedBadge type="estate" size="small" />
            </div>
            <p>
              Connect with top-rated managers and trusted property firms to manage your property seamlessly. 
              Filter by location and ratings to find the perfect fit.
            </p>
            {/* FIXED: Link to marketplace with estate management filter */}
            <Link to="/services?category=estate-management" className="promo-button">
              Find a Manager
            </Link>
          </div>

          <div className="promo-card verify-promo">
            <div className="promo-header">
              <h2>Are You a Landlord?</h2>
              <VerifiedBadge type="landlord" size="small" />
            </div>
            <p>
              Get your property verified and attract serious tenants directly — 
              no agents, no stress. Verified landlords get 3x more responses!
            </p>
            <Link to="/verify" className="promo-button">
              Get Verified Now
            </Link>
          </div>
        </section>

        {/* Verification Stats */}
        <div className="verification-stats">
          <h3>Why Get Verified?</h3>
          <div className="stats-grid">
            <div className="stat-item">
              <div className="stat-number">3x</div>
              <div className="stat-label">More Responses</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">50%</div>
              <div className="stat-label">Faster Transactions</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">90%</div>
              <div className="stat-label">Higher Trust Score</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">⭐</div>
              <div className="stat-label">Priority Placement</div>
            </div>
          </div>
        </div>
      </main>
    </>
  )
}

export default Home