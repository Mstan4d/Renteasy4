// src/modules/messaging/pages/Messages.jsx
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from "../../../shared/context/AuthContext";
import { useWebSocket } from "../../../shared/context/WebSocketContext";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import Header from "../../../shared/components/Header";
import BottomNav from "../../../shared/components/layout/BottomNav";
import useAudioRecorder from "../../../shared/hooks/UseAudioRecorder"; // Import the hook
//import EmojiPicker from '@emoji-mart/react';
//import data from '@emoji-mart/data';
import { 
  Search, Mic, Smile, Paperclip, Send, Users,
  Phone, Video, MoreVertical, Check, CheckCheck,
  Image as ImageIcon, File, X, AlertCircle
} from 'lucide-react';
import "./Messages.css";

/**
 * Messages - Complete messaging/chat interface for RentEasy
 * 
 * Features:
 * - Real-time messaging with simulated WebSocket
 * - Role-based conversation access
 * - File attachments (images, videos, PDFs)
 * - Online status indicators
 * - Unread message badges
 * - Conversation filtering by role
 * - Integration with property listings
 * 
 * Role Permissions:
 * - Tenants: Can message landlords/managers
 * - Landlords: Can message tenants/managers
 * - Managers: Can view assigned conversations
 * - Admins: Can view all conversations
 */
const Messages = () => {
  // ================= HOOK INITIALIZATION =================
  const { user } = useAuth();
  const { sendMessage: wsSendMessage, sendTyping, isConnected } = useWebSocket();
  const { conversationId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Refs
  const chatWindowRef = useRef(null);
  const fileInputRef = useRef(null);
  
  // Audio recorder hook
  const {
    isRecording,
    audioBlob,
    audioUrl,
    recordingTime,
    recordingPermission,
    startRecording,
    stopRecording,
    cancelRecording,
    resetRecording,
    hasAudio,
  } = useAudioRecorder();

  // ================= STATE MANAGEMENT =================
  const [conversations, setConversations] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [unreadCount, setUnreadCount] = useState(0);
  const [onlineUsers, setOnlineUsers] = useState({});
  const [isTyping, setIsTyping] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  // const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isRecordingAudio, setIsRecordingAudio] = useState(false); // Fixed: Added this state
  const [messages, setMessages] = useState([]); // Fixed: Added messages state
  const [typingUsers, setTypingUsers] = useState([]);
  
  // ================= CONSTANTS & UTILITIES =================
  const ROLE_PERMISSIONS = {
    tenant: {
      canSend: true,
      canInitiate: true,
      canViewAll: false,
      allowedRecipients: ['landlord', 'manager']
    },
    landlord: {
      canSend: true,
      canInitiate: true,
      canViewAll: false,
      allowedRecipients: ['tenant', 'manager']
    },
    manager: {
      canSend: true,
      canInitiate: false,
      canViewAll: false,
      allowedRecipients: ['tenant', 'landlord'],
      viewFilter: 'assigned'
    },
    admin: {
      canSend: false,
      canInitiate: false,
      canViewAll: true,
      allowedRecipients: []
    }
  };
  
  const MESSAGE_TYPES = {
    TEXT: 'text',
    IMAGE: 'image',
    VIDEO: 'video',
    DOCUMENT: 'document',
    SYSTEM: 'system',
    VOICE: 'voice' // Added voice type
  };
  
  const generateId = (prefix = 'id') => {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  };
  
  const formatTime = (timestamp) => {
    if (!timestamp) return 'Just now';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  const getUserInitials = (name) => {
    if (!name) return '??';
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };
  
  const getOnlineStatus = (userId) => {
    const userData = onlineUsers[userId];
    if (!userData) return { isOnline: false, lastSeen: 'Never' };
    
    const lastSeen = new Date(userData.lastSeen);
    const now = new Date();
    const diffMs = now - lastSeen;
    const isOnline = diffMs < 120000;
    
    return {
      isOnline,
      lastSeen: isOnline ? 'Online' : `Last seen ${formatTime(userData.lastSeen)}`
    };
  };

  // Add this somewhere in your JSX to show notifications
{notifications.length > 0 && (
    <div className="notifications-panel">
      <h3>Notifications ({notifications.length})</h3>
      <button onClick={clearNotifications}>Clear All</button>
      {notifications.map(notif => (
        <div key={notif.id} className="notification">
          <p>{notif.message}</p>
          <small>{new Date(notif.timestamp).toLocaleTimeString()}</small>
        </div>
      ))}
    </div>
  )}
  
  // ================= AUDIO RECORDING FUNCTIONS =================
  
  // Handle voice message recording
  const handleVoiceMessage = async () => {
    if (!isRecording) {
      const started = await startRecording();
      if (started) {
        setIsRecordingAudio(true);
      }
    } else {
      stopRecording();
      setIsRecordingAudio(false);
    }
  };
  
  // Send recorded audio
  useEffect(() => {
    if (audioBlob && audioUrl && !isRecording) {
      const voiceMessage = {
        id: generateId('msg'),
        audioUrl,
        duration: recordingTime,
        senderId: user?.id || 'current',
        timestamp: new Date().toISOString(),
        type: MESSAGE_TYPES.VOICE,
        read: false,
        blob: audioBlob
      };

      // Send via WebSocket
      if (isConnected) {
        wsSendMessage(voiceMessage);
      }

      // Add to messages locally
       // Also update local state
    setMessages(prev => [...prev, {
        ...messageData,
        id: Date.now().toString(),
        read: false
      }]);
      
      setNewMessage('');
    };
      
      // Reset after sending
      setTimeout(() => {
        resetRecording();
      }, 100);
    }, [audioBlob, audioUrl, isRecording, recordingTime, user?.id, isConnected, wsSendMessage, resetRecording]);
  
  // ================= DATA LOADING =================
  
  const loadMockConversations = () => {
    const mockUsers = [
      { id: 'landlord_1', name: 'John Properties', role: 'landlord' },
      { id: 'tenant_1', name: 'Sarah Johnson', role: 'tenant' },
      { id: 'manager_1', name: 'Mike Manager', role: 'manager' },
      { id: 'tenant_2', name: 'David Smith', role: 'tenant' }
    ];
    
    return [
      {
        id: 'conv_1',
        listingId: 'prop_123',
        listingTitle: '3 Bedroom Duplex in Lekki',
        participants: [
          { id: user?.id || 'current', name: user?.name || 'You', role: user?.role || 'tenant' },
          mockUsers[0]
        ],
        messages: [
          {
            id: 'msg_1',
            senderId: mockUsers[0].id,
            type: MESSAGE_TYPES.TEXT,
            content: 'Hello, I saw your inquiry about the property. When would you like to schedule a viewing?',
            timestamp: Date.now() - 3600000,
            readBy: { [user?.role || 'tenant']: true }
          },
          {
            id: 'msg_2',
            senderId: user?.id || 'current',
            type: MESSAGE_TYPES.TEXT,
            content: 'Hi! I\'m available this Saturday afternoon. What time works for you?',
            timestamp: Date.now() - 1800000,
            readBy: { landlord: false }
          }
        ],
        lastUpdated: Date.now() - 1800000,
        unreadCount: 1
      }
    ];
  };
  
  const filterConversationsByRole = (convs) => {
    if (!user) return [];
    
    const permissions = ROLE_PERMISSIONS[user.role] || ROLE_PERMISSIONS.tenant;
    
    if (permissions.canViewAll) return convs;
    
    return convs.filter(conv => {
      const isParticipant = conv.participants.some(p => p.id === user.id);
      
      if (user.role === 'manager' && permissions.viewFilter === 'assigned') {
        const assignedProperties = JSON.parse(localStorage.getItem('assigned_properties') || '[]');
        return isParticipant || assignedProperties.includes(conv.listingId);
      }
      
      return isParticipant;
    });
  };
  
  const calculateUnreadCount = (convs) => {
    return convs.reduce((total, conv) => {
      const userMessages = conv.messages.filter(msg => 
        msg.senderId !== user?.id && !msg.readBy?.[user?.role || 'tenant']
      );
      return total + userMessages.length;
    }, 0);
  };
  
  // ================= CONVERSATION MANAGEMENT =================
  
  const openConversation = (conversation) => {
    setActiveConversation(conversation);
    setMessages(conversation.messages || []);
    
    const updatedConversations = conversations.map(conv => {
      if (conv.id === conversation.id) {
        const updatedMessages = conv.messages.map(msg => ({
          ...msg,
          readBy: {
            ...msg.readBy,
            [user?.role || 'tenant']: true
          }
        }));
        
        return {
          ...conv,
          messages: updatedMessages,
          unreadCount: 0
        };
      }
      return conv;
    });
    
    setConversations(updatedConversations);
    setUnreadCount(calculateUnreadCount(updatedConversations));
  };
  
  const handleSendMessage = () => {
    if (!newMessage.trim() && !selectedFile) return;
  
    const messageData = {
      text: newMessage,
      senderId: user.id,
      senderName: user.name,
      conversationId: activeConversation?.id,
      timestamp: new Date().toISOString(),
      type: selectedFile ? 'file' : 'text',
    };
  
    // Use the mock WebSocket
    sendMessage(messageData);
  
    
    const permissions = ROLE_PERMISSIONS[user?.role || 'tenant'];
    if (!permissions.canSend) {
      alert('You do not have permission to send messages');
      return;
    }
    
    const message = {
      id: generateId('msg'),
      senderId: user?.id || 'current',
      type: selectedFile ? getFileType(selectedFile) : MESSAGE_TYPES.TEXT,
      content: newMessage.trim(),
      attachment: selectedFile ? URL.createObjectURL(selectedFile) : null,
      fileName: selectedFile?.name || null,
      timestamp: Date.now(),
      readBy: {
        [user?.role || 'tenant']: true
      }
    };
    
    // Send via WebSocket
    if (isConnected) {
      wsSendMessage(message);
    }
    
    // Update local state
    const updatedMessages = [...messages, message];
    setMessages(updatedMessages);
    
    const updatedConversations = conversations.map(conv => {
      if (conv.id === activeConversation.id) {
        return {
          ...conv,
          messages: updatedMessages,
          lastUpdated: Date.now(),
          unreadCount: 0
        };
      }
      return conv;
    });
    
    setConversations(updatedConversations);
    setActiveConversation(prev => ({
      ...prev,
      messages: updatedMessages,
      lastUpdated: Date.now()
    }));
    
    // Reset form
    setNewMessage('');
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  const getFileType = (file) => {
    if (file.type.startsWith('image/')) return MESSAGE_TYPES.IMAGE;
    if (file.type.startsWith('video/')) return MESSAGE_TYPES.VIDEO;
    return MESSAGE_TYPES.DOCUMENT;
  };
  
  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    if (file.size > 10 * 1024 * 1024) {
      alert('File size must be less than 10MB');
      return;
    }
    
    setSelectedFile(file);
  };
  
  const startNewConversation = (recipient, listingId = null) => {
    const permissions = ROLE_PERMISSIONS[user?.role || 'tenant'];
    
    if (!permissions.canInitiate) {
      alert('You cannot initiate new conversations');
      return;
    }
    
    if (!permissions.allowedRecipients.includes(recipient.role)) {
      alert(`You cannot message ${recipient.role}s`);
      return;
    }
    
    const newConv = {
      id: generateId('conv'),
      listingId,
      listingTitle: listingId ? `Property ${listingId}` : 'General Inquiry',
      participants: [
        { id: user?.id || 'current', name: user?.name || 'You', role: user?.role || 'tenant' },
        recipient
      ],
      messages: [],
      lastUpdated: Date.now(),
      unreadCount: 0
    };
    
    const updatedConversations = [newConv, ...conversations];
    setConversations(updatedConversations);
    openConversation(newConv);
  };
  
  // ================= EFFECTS =================
  
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      
      try {
        const mockConversations = loadMockConversations();
        const filteredConversations = filterConversationsByRole(mockConversations);
        setConversations(filteredConversations);
        setUnreadCount(calculateUnreadCount(filteredConversations));
        
        const mockOnlineUsers = {
          'landlord_1': { lastSeen: Date.now(), name: 'John Properties', role: 'landlord' },
          'manager_1': { lastSeen: Date.now() - 30000, name: 'Mike Manager', role: 'manager' }
        };
        setOnlineUsers(mockOnlineUsers);
        
      } catch (error) {
        console.error('Error loading messages:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    if (user) {
      loadData();
    }
  }, [user]);
  
  useEffect(() => {
    if (chatWindowRef.current && activeConversation) {
      chatWindowRef.current.scrollTop = chatWindowRef.current.scrollHeight;
    }
  }, [messages]);
  
  // ================= RENDER FUNCTIONS =================
  
  const renderMessage = (message) => {
    if (!activeConversation) return null;
    
    const sender = activeConversation.participants.find(p => p.id === message.senderId);
    const isCurrentUser = message.senderId === user?.id;
    
    return (
      <div key={message.id} className={`message ${isCurrentUser ? 'outgoing' : 'incoming'}`}>
        {!isCurrentUser && (
          <div className="message-avatar">
            <div className="avatar-initials">
              {getUserInitials(sender?.name)}
            </div>
          </div>
        )}
        
        <div className="message-content">
          {!isCurrentUser && (
            <div className="message-sender">
              <span className="sender-name">{sender?.name}</span>
            </div>
          )}
          
          <div className="message-bubble">
            {message.type === MESSAGE_TYPES.IMAGE && (
              <img 
                src={message.attachment} 
                alt={message.fileName || 'Attachment'} 
                className="message-attachment image"
              />
            )}
            
            {message.type === MESSAGE_TYPES.VIDEO && (
              <video 
                src={message.attachment} 
                controls 
                className="message-attachment video"
              />
            )}
            
            {message.type === MESSAGE_TYPES.DOCUMENT && (
              <a 
                href={message.attachment} 
                download={message.fileName}
                className="message-attachment document"
              >
                📎 {message.fileName || 'Document'}
              </a>
            )}
            
            {message.type === MESSAGE_TYPES.VOICE && (
              <div className="voice-message">
                <audio controls src={message.audioUrl} />
                <span className="duration">{message.duration}</span>
              </div>
            )}
            
            {message.content && message.type === MESSAGE_TYPES.TEXT && (
              <div className="message-text">{message.content}</div>
            )}
            
            <div className="message-meta">
              <span className="message-time">{formatTime(message.timestamp)}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  // ================= MAIN RENDER =================
  
  if (!user) {
    return (
      <div className="messages-container">
        <Header title="Messages" />
        <div className="auth-required">
          <h2>Please login to access messages</h2>
          <button 
            className="btn btn-primary"
            onClick={() => navigate('/login')}
          >
            Go to Login
          </button>
        </div>
        <BottomNav />
      </div>
    );
  }
  
  return (
    <div className="messages-container">
      <Header title="Messages" />
      
      <div className="messages-content">
        {/* Conversation List */}
        <div className="conversations-sidebar">
          <div className="conversation-search">
            <Search size={20} />
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button 
              className="create-group-btn"
              onClick={() => alert('New group feature coming soon!')}
            >
              <Users size={20} /> New Group
            </button>
          </div>
          
          <div className="conversations-list">
            {conversations.map(conv => {
              const otherParticipant = conv.participants.find(p => p.id !== user?.id);
              const status = getOnlineStatus(otherParticipant?.id);
              
              return (
                <div
                  key={conv.id}
                  className={`conversation-item ${activeConversation?.id === conv.id ? 'active' : ''}`}
                  onClick={() => openConversation(conv)}
                >
                  <div className="conversation-avatar">
                    <div className="avatar-initials">
                      {getUserInitials(otherParticipant?.name)}
                    </div>
                    {status.isOnline && <div className="online-indicator" />}
                    {conv.unreadCount > 0 && (
                      <span className="unread-badge">{conv.unreadCount}</span>
                    )}
                  </div>
                  
                  <div className="conversation-info">
                    <div className="conversation-header">
                      <h4>{otherParticipant?.name}</h4>
                      <span className="timestamp">{formatTime(conv.lastUpdated)}</span>
                    </div>
                    
                    <div className="conversation-preview">
                      <p>
                        {conv.messages.length > 0 
                          ? conv.messages[conv.messages.length - 1].content?.substring(0, 30) + '...'
                          : 'Start a conversation'
                        }
                      </p>
                    </div>
                    
                    {conv.listingTitle && (
                      <div className="listing-info">
                        <span className="listing-tag">🏠 {conv.listingTitle}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Chat Area */}
        <div className="chat-area">
          {activeConversation ? (
            <>
              <div className="chat-header">
                <div className="chat-partner">
                  <div className="chat-avatar">
                    <div className="avatar-initials">
                      {getUserInitials(activeConversation.participants.find(p => p.id !== user?.id)?.name)}
                    </div>
                  </div>
                  <div>
                    <h3>{activeConversation.participants.find(p => p.id !== user?.id)?.name}</h3>
                    <p className="online-status">
                      {getOnlineStatus(activeConversation.participants.find(p => p.id !== user?.id)?.id).lastSeen}
                    </p>
                  </div>
                </div>
                <div className="conversation-actions">
                  <Phone size={20} />
                  <Video size={20} />
                  <MoreVertical size={20} />
                </div>
              </div>
              
              <div ref={chatWindowRef} className="messages-area">
                {messages.map(renderMessage)}
                <div ref={(el) => { if (el) el.scrollIntoView(); }} />
              </div>
              
              <div className="message-input-area">
                <button 
                  className="attach-button"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Paperclip size={20} />
                </button>
                
                <input
                  type="file"
                  ref={fileInputRef}
                  style={{ display: 'none' }}
                  onChange={handleFileSelect}
                  accept="image/*,application/pdf,text/plain"
                />
                
                <div className="message-input-wrapper">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    placeholder="Type your message..."
                  />
                </div>
                
               {/*
                <button
                  className="emoji-button"
                  onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                   >
                <Smile size={20} />
                </button>
                */}
                
                {newMessage.trim() ? (
                  <button className="send-button" onClick={handleSendMessage}>
                    <Send size={20} />
                  </button>
                ) : (
                  <button 
                    className={`record-button ${isRecording ? 'recording' : ''}`}
                    onClick={handleVoiceMessage}
                    disabled={recordingPermission === false}
                    title={recordingPermission === false ? "Microphone access denied" : "Record voice message"}
                  >
                    <Mic size={20} />
                    {isRecording && <span className="recording-dot"></span>}
                  </button>
                )}
                
                {/* Recording Indicator */}
                {isRecording && (
                  <div className="recording-indicator">
                    <div className="recording-visualizer">
                      {[...Array(5)].map((_, i) => (
                        <div 
                          key={i} 
                          className="recording-bar"
                          style={{
                            animationDelay: `${i * 0.1}s`,
                            height: `${20 + Math.random() * 30}px`
                          }}
                        />
                      ))}
                    </div>
                    <span className="recording-timer">{recordingTime}</span>
                    <button 
                      className="stop-recording-btn"
                      onClick={() => {
                        stopRecording();
                        setIsRecordingAudio(false);
                      }}
                    >
                      Stop
                    </button>
                    <button 
                      className="cancel-recording-btn"
                      onClick={() => {
                        cancelRecording();
                        setIsRecordingAudio(false);
                      }}
                    >
                      <X size={16} />
                    </button>
                  </div>
                )}
                
                {/* Microphone Permission Warning */}
                {recordingPermission === false && (
                  <div className="permission-warning">
                    <AlertCircle size={16} />
                    <span>Microphone access needed for voice messages</span>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="chat-placeholder">
              <div className="placeholder-icon">💬</div>
              <h3>Select a conversation</h3>
              <p>Choose a conversation from the list or start a new one</p>
              <button 
                className="btn btn-primary"
                onClick={() => {
                  const mockLandlord = {
                    id: 'new_landlord',
                    name: 'New Landlord',
                    role: 'landlord'
                  };
                  startNewConversation(mockLandlord, 'prop_789');
                }}
              >
                Start New Conversation
              </button>
            </div>
          )}
        </div>
      </div>
      
      <BottomNav />
    </div>
  );
};

export default Messages;