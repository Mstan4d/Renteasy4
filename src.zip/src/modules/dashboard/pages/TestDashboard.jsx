// src/modules/dashboard/pages/TestDashboard.jsx
import React from 'react';

const TestDashboard = () => {
  console.log('TestDashboard rendering');
  
  return (
    <div style={{ 
      padding: '40px', 
      backgroundColor: '#f8f9fa', 
      minHeight: '400px',
      textAlign: 'center'
    }}>
      <h1 style={{ color: '#dc3545' }}>✅ TEST DASHBOARD WORKING!</h1>
      <div style={{ 
        backgroundColor: 'white', 
        padding: '30px', 
        margin: '20px auto', 
        borderRadius: '10px',
        maxWidth: '600px',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
      }}>
        <h3>If you can see this:</h3>
        <ul style={{ textAlign: 'left', display: 'inline-block' }}>
          <li>✅ Routing is working</li>
          <li>✅ Authentication is working</li>
          <li>✅ PrivateRoute is working</li>
          <li>✅ User has correct role</li>
        </ul>
        <div style={{ marginTop: '20px', padding: '10px', backgroundColor: '#e9ecef', borderRadius: '5px' }}>
          <p><strong>Next step:</strong> Check browser console for debugging info</p>
        </div>
      </div>
    </div>
  );
};

export default TestDashboard;