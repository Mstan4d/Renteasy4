// src/modules/admin/pages/AdminVerification.jsx
import React, { useState, useEffect } from 'react';
import {
  Users, ShieldCheck, CheckCircle, XCircle, Clock,
  Search, Filter, Eye, Download, AlertCircle,
  UserCheck, UserX, Mail, Phone, MapPin, Calendar,
  FileText, Image as ImageIcon, ExternalLink
} from 'lucide-react';
import './AdminVerification.css';

const AdminVerification = () => {
  const [verifications, setVerifications] = useState([]);
  const [filteredVerifications, setFilteredVerifications] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('pending');
  const [selectedVerification, setSelectedVerification] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    approved: 0,
    rejected: 0,
    underReview: 0
  });

  useEffect(() => {
    loadVerifications();
  }, []);

  useEffect(() => {
    filterVerifications();
  }, [searchTerm, statusFilter, verifications]);

  const loadVerifications = () => {
    try {
      const usersData = JSON.parse(localStorage.getItem('rentEasyUsers') || '[]');
      const verificationData = JSON.parse(localStorage.getItem('kycVerifications') || '[]');
      
      // If no KYC verifications exist, create sample data from users
      if (verificationData.length === 0) {
        const sampleVerifications = generateSampleVerifications(usersData);
        localStorage.setItem('kycVerifications', JSON.stringify(sampleVerifications));
        setVerifications(sampleVerifications);
      } else {
        setVerifications(verificationData);
      }
      
      calculateStats(verificationData.length > 0 ? verificationData : generateSampleVerifications(usersData));
    } catch (error) {
      console.error('Error loading verifications:', error);
    }
  };

  const generateSampleVerifications = (users) => {
    const kycStatuses = ['pending', 'approved', 'rejected', 'under_review'];
    const idTypes = ['national_id', 'passport', 'drivers_license', 'voters_card'];
    
    return users.slice(0, 15).map((user, index) => ({
      id: `kyc-${Date.now()}-${index}`,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      userPhone: user.phone || `+23480${Math.floor(Math.random() * 90000000) + 10000000}`,
      userRole: user.role || 'tenant',
      status: kycStatuses[index % kycStatuses.length],
      idType: idTypes[index % idTypes.length],
      idNumber: `${idTypes[index % idTypes.length].toUpperCase().substring(0, 3)}${10000 + index}`,
      submittedAt: new Date(Date.now() - index * 86400000).toISOString(),
      reviewedAt: index % 3 === 0 ? new Date(Date.now() - index * 43200000).toISOString() : null,
      reviewedBy: index % 3 === 0 ? 'Admin' : null,
      documents: [
        { type: 'id_front', url: `https://example.com/id-front-${index}.jpg`, verified: index % 3 === 0 },
        { type: 'id_back', url: `https://example.com/id-back-${index}.jpg`, verified: index % 3 === 0 },
        { type: 'selfie', url: `https://example.com/selfie-${index}.jpg`, verified: index % 3 === 0 }
      ],
      addressProof: {
        type: 'utility_bill',
        url: `https://example.com/utility-${index}.jpg`,
        verified: index % 3 === 0
      },
      additionalInfo: {
        occupation: ['Software Engineer', 'Business Owner', 'Student', 'Teacher'][index % 4],
        incomeRange: ['₦100,000 - ₦500,000', '₦500,000 - ₦2,000,000', '₦2,000,000+'][index % 3],
        employmentStatus: ['employed', 'self-employed', 'student'][index % 3]
      },
      notes: index % 4 === 0 ? 'Requires additional verification' : '',
      riskLevel: index % 5 === 0 ? 'high' : index % 3 === 0 ? 'medium' : 'low'
    }));
  };

  const calculateStats = (verificationsData) => {
    const total = verificationsData.length;
    const pending = verificationsData.filter(v => v.status === 'pending').length;
    const approved = verificationsData.filter(v => v.status === 'approved').length;
    const rejected = verificationsData.filter(v => v.status === 'rejected').length;
    const underReview = verificationsData.filter(v => v.status === 'under_review').length;
    
    setStats({ total, pending, approved, rejected, underReview });
  };

  const filterVerifications = () => {
    let filtered = [...verifications];
    
    if (searchTerm) {
      filtered = filtered.filter(verification =>
        verification.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        verification.userEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
        verification.idNumber.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(verification => verification.status === statusFilter);
    }
    
    setFilteredVerifications(filtered);
  };

  const viewVerificationDetails = (verification) => {
    setSelectedVerification(verification);
    setShowModal(true);
  };

  const updateVerificationStatus = (verificationId, newStatus, notes = '') => {
    const updatedVerifications = verifications.map(verification =>
      verification.id === verificationId 
        ? { 
            ...verification, 
            status: newStatus,
            reviewedAt: new Date().toISOString(),
            reviewedBy: 'Admin',
            notes: notes || verification.notes
          } 
        : verification
    );
    
    setVerifications(updatedVerifications);
    localStorage.setItem('kycVerifications', JSON.stringify(updatedVerifications));
    calculateStats(updatedVerifications);
    
    // Also update user verification status
    const verification = updatedVerifications.find(v => v.id === verificationId);
    if (verification) {
      const users = JSON.parse(localStorage.getItem('rentEasyUsers') || '[]');
      const updatedUsers = users.map(user =>
        user.id === verification.userId
          ? { 
              ...user, 
              kycStatus: newStatus,
              verified: newStatus === 'approved',
              verifiedAt: newStatus === 'approved' ? new Date().toISOString() : user.verifiedAt
            }
          : user
      );
      localStorage.setItem('rentEasyUsers', JSON.stringify(updatedUsers));
    }
    
    if (selectedVerification?.id === verificationId) {
      setSelectedVerification(updatedVerifications.find(v => v.id === verificationId));
    }
  };

  const bulkApprove = () => {
    if (!window.confirm(`Approve ${filteredVerifications.length} pending verifications?`)) return;
    
    const updatedVerifications = verifications.map(verification =>
      filteredVerifications.some(f => f.id === verification.id) && verification.status === 'pending'
        ? { 
            ...verification, 
            status: 'approved',
            reviewedAt: new Date().toISOString(),
            reviewedBy: 'Admin'
          }
        : verification
    );
    
    setVerifications(updatedVerifications);
    localStorage.setItem('kycVerifications', JSON.stringify(updatedVerifications));
    calculateStats(updatedVerifications);
    
    // Update users
    const users = JSON.parse(localStorage.getItem('rentEasyUsers') || '[]');
    const updatedUsers = users.map(user => {
      const verification = filteredVerifications.find(v => v.userId === user.id && v.status === 'pending');
      if (verification) {
        return {
          ...user,
          kycStatus: 'approved',
          verified: true,
          verifiedAt: new Date().toISOString()
        };
      }
      return user;
    });
    localStorage.setItem('rentEasyUsers', JSON.stringify(updatedUsers));
    
    alert(`${filteredVerifications.length} verifications approved successfully!`);
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'approved': return <CheckCircle size={16} className="approved" />;
      case 'pending': return <Clock size={16} className="pending" />;
      case 'rejected': return <XCircle size={16} className="rejected" />;
      case 'under_review': return <AlertCircle size={16} className="under-review" />;
      default: return <Clock size={16} />;
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'approved': return 'success';
      case 'pending': return 'warning';
      case 'rejected': return 'danger';
      case 'under_review': return 'info';
      default: return 'secondary';
    }
  };

  const getRiskColor = (riskLevel) => {
    switch(riskLevel) {
      case 'high': return 'danger';
      case 'medium': return 'warning';
      case 'low': return 'success';
      default: return 'secondary';
    }
  };

  const exportVerifications = () => {
    const csvContent = [
      ['User ID', 'Name', 'Email', 'ID Type', 'ID Number', 'Status', 'Submitted Date', 'Risk Level'],
      ...filteredVerifications.map(v => [
        v.userId,
        v.userName,
        v.userEmail,
        v.idType,
        v.idNumber,
        v.status,
        new Date(v.submittedAt).toLocaleDateString(),
        v.riskLevel
      ])
    ].map(row => row.join(',')).join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kyc_verifications_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="admin-verification">
      <div className="verification-header">
        <div className="header-left">
          <h1><ShieldCheck size={28} /> KYC Verification</h1>
          <p>Verify user identity documents and KYC submissions</p>
        </div>
        <div className="header-right">
          {stats.pending > 0 && (
            <button className="btn-bulk-approve" onClick={bulkApprove}>
              <CheckCircle size={18} /> Approve All ({stats.pending})
            </button>
          )}
          <button className="btn-export" onClick={exportVerifications}>
            <Download size={18} /> Export
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="verification-stats">
        <div className="stat-card">
          <div className="stat-icon total">
            <Users size={24} />
          </div>
          <div className="stat-content">
            <h3>{stats.total}</h3>
            <p>Total Submissions</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon pending">
            <Clock size={24} />
          </div>
          <div className="stat-content">
            <h3>{stats.pending}</h3>
            <p>Pending Review</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon approved">
            <UserCheck size={24} />
          </div>
          <div className="stat-content">
            <h3>{stats.approved}</h3>
            <p>Approved</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon rejected">
            <UserX size={24} />
          </div>
          <div className="stat-content">
            <h3>{stats.rejected}</h3>
            <p>Rejected</p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon under-review">
            <AlertCircle size={24} />
          </div>
          <div className="stat-content">
            <h3>{stats.underReview}</h3>
            <p>Under Review</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="verification-filters">
        <div className="search-box">
          <Search size={18} />
          <input
            type="text"
            placeholder="Search by name, email, or ID number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filter-group">
          <select 
            value={statusFilter} 
            onChange={(e) => setStatusFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
            <option value="under_review">Under Review</option>
          </select>
          
          <button className="btn-filter" onClick={() => {
            setSearchTerm('');
            setStatusFilter('all');
          }}>
            <Filter size={16} /> Clear Filters
          </button>
        </div>
      </div>

      {/* Verification List */}
      <div className="verification-list">
        {filteredVerifications.length > 0 ? (
          <div className="verification-grid">
            {filteredVerifications.map(verification => (
              <div key={verification.id} className="verification-card">
                <div className="card-header">
                  <div className="user-info">
                    <div className="user-avatar">
                      {verification.userName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <h4>{verification.userName}</h4>
                      <div className="user-meta">
                        <span><Mail size={12} /> {verification.userEmail}</span>
                        <span><Phone size={12} /> {verification.userPhone}</span>
                      </div>
                    </div>
                  </div>
                  <div className="status-badges">
                    <span className={`status-badge ${getStatusColor(verification.status)}`}>
                      {getStatusIcon(verification.status)} {verification.status.replace('_', ' ')}
                    </span>
                    <span className={`risk-badge ${getRiskColor(verification.riskLevel)}`}>
                      Risk: {verification.riskLevel}
                    </span>
                  </div>
                </div>
                
                <div className="card-body">
                  <div className="kyc-details">
                    <div className="detail-row">
                      <span className="label">ID Type:</span>
                      <span className="value">{verification.idType.replace('_', ' ')}</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">ID Number:</span>
                      <span className="value">{verification.idNumber}</span>
                    </div>
                    <div className="detail-row">
                      <span className="label">Submitted:</span>
                      <span className="value">
                        {new Date(verification.submittedAt).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="detail-row">
                      <span className="label">Role:</span>
                      <span className="value">{verification.userRole}</span>
                    </div>
                  </div>
                  
                  <div className="documents-preview">
                    <div className="document-item">
                      <ImageIcon size={14} />
                      <span>ID Front</span>
                      {verification.documents[0]?.verified && (
                        <CheckCircle size={12} className="verified" />
                      )}
                    </div>
                    <div className="document-item">
                      <ImageIcon size={14} />
                      <span>ID Back</span>
                      {verification.documents[1]?.verified && (
                        <CheckCircle size={12} className="verified" />
                      )}
                    </div>
                    <div className="document-item">
                      <ImageIcon size={14} />
                      <span>Selfie</span>
                      {verification.documents[2]?.verified && (
                        <CheckCircle size={12} className="verified" />
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="card-footer">
                  <button 
                    className="btn-view-details"
                    onClick={() => viewVerificationDetails(verification)}
                  >
                    <Eye size={16} /> View Details
                  </button>
                  
                  {verification.status === 'pending' && (
                    <div className="quick-actions">
                      <button 
                        className="btn-approve"
                        onClick={() => updateVerificationStatus(verification.id, 'approved')}
                      >
                        Approve
                      </button>
                      <button 
                        className="btn-reject"
                        onClick={() => {
                          const reason = prompt('Enter rejection reason:');
                          if (reason) {
                            updateVerificationStatus(verification.id, 'rejected', reason);
                          }
                        }}
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="no-verifications">
            <ShieldCheck size={48} />
            <p>No verifications found</p>
            <small>All KYC submissions have been processed</small>
          </div>
        )}
      </div>

      {/* Verification Detail Modal */}
      {showModal && selectedVerification && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3>KYC Verification Details</h3>
              <button className="btn-close" onClick={() => setShowModal(false)}>
                <XCircle size={20} />
              </button>
            </div>
            
            <div className="modal-body">
              <div className="user-profile">
                <div className="profile-header">
                  <div className="user-avatar-large">
                    {selectedVerification.userName.charAt(0).toUpperCase()}
                  </div>
                  <div className="profile-info">
                    <h4>{selectedVerification.userName}</h4>
                    <p>{selectedVerification.userEmail}</p>
                    <div className="profile-meta">
                      <span><Phone size={14} /> {selectedVerification.userPhone}</span>
                      <span><Users size={14} /> {selectedVerification.userRole}</span>
                    </div>
                  </div>
                  <div className="profile-status">
                    <span className={`status-badge ${getStatusColor(selectedVerification.status)}`}>
                      {getStatusIcon(selectedVerification.status)} {selectedVerification.status.replace('_', ' ')}
                    </span>
                    <span className={`risk-badge ${getRiskColor(selectedVerification.riskLevel)}`}>
                      Risk: {selectedVerification.riskLevel}
                    </span>
                  </div>
                </div>
                
                <div className="verification-details">
                  <div className="detail-section">
                    <h5>Identification Documents</h5>
                    <div className="documents-grid">
                      {selectedVerification.documents.map((doc, index) => (
                        <div key={index} className="document-card">
                          <div className="document-preview">
                            <ImageIcon size={24} />
                            <span>{doc.type.replace('_', ' ').toUpperCase()}</span>
                          </div>
                          <div className="document-actions">
                            <button 
                              className="btn-view-doc"
                              onClick={() => window.open(doc.url, '_blank')}
                            >
                              <ExternalLink size={14} /> View
                            </button>
                            <span className={`doc-status ${doc.verified ? 'verified' : 'unverified'}`}>
                              {doc.verified ? '✓ Verified' : 'Pending'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="detail-section">
                    <h5>KYC Information</h5>
                    <div className="info-grid">
                      <div className="info-item">
                        <span className="label">ID Type</span>
                        <span className="value">{selectedVerification.idType.replace('_', ' ')}</span>
                      </div>
                      <div className="info-item">
                        <span className="label">ID Number</span>
                        <span className="value">{selectedVerification.idNumber}</span>
                      </div>
                      <div className="info-item">
                        <span className="label">Submitted</span>
                        <span className="value">
                          {new Date(selectedVerification.submittedAt).toLocaleString()}
                        </span>
                      </div>
                      {selectedVerification.reviewedAt && (
                        <div className="info-item">
                          <span className="label">Reviewed</span>
                          <span className="value">
                            {new Date(selectedVerification.reviewedAt).toLocaleString()}
                          </span>
                        </div>
                      )}
                      <div className="info-item">
                        <span className="label">Occupation</span>
                        <span className="value">{selectedVerification.additionalInfo.occupation}</span>
                      </div>
                      <div className="info-item">
                        <span className="label">Income Range</span>
                        <span className="value">{selectedVerification.additionalInfo.incomeRange}</span>
                      </div>
                    </div>
                  </div>
                  
                  {selectedVerification.notes && (
                    <div className="detail-section">
                      <h5>Notes</h5>
                      <div className="notes-box">
                        <p>{selectedVerification.notes}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="modal-footer">
              <div className="verification-actions">
                {selectedVerification.status === 'pending' && (
                  <>
                    <button 
                      className="btn-approve-large"
                      onClick={() => updateVerificationStatus(selectedVerification.id, 'approved')}
                    >
                      <CheckCircle size={18} /> Approve KYC
                    </button>
                    <button 
                      className="btn-reject-large"
                      onClick={() => {
                        const reason = prompt('Enter rejection reason:');
                        if (reason) {
                          updateVerificationStatus(selectedVerification.id, 'rejected', reason);
                        }
                      }}
                    >
                      <XCircle size={18} /> Reject KYC
                    </button>
                    <button 
                      className="btn-review"
                      onClick={() => {
                        const notes = prompt('Enter review notes:');
                        if (notes) {
                          updateVerificationStatus(selectedVerification.id, 'under_review', notes);
                        }
                      }}
                    >
                      <AlertCircle size={18} /> Mark for Review
                    </button>
                  </>
                )}
                <button 
                  className="btn-close-modal"
                  onClick={() => setShowModal(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminVerification;