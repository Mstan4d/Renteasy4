// src/modules/manager/pages/ManagerDashboard.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../../shared/context/AuthContext';
import Header from '../../../shared/components/Header';
import Sidebar from '../../../shared/components/layout/Sidebar';
import './ManagerDashboard.css';

/**
 * ManagerDashboard - Main dashboard interface for property managers
 * 
 * Features:
 * - Overview of assigned listings
 * - KYC status tracking and actions
 * - Real-time statistics dashboard
 * - Interactive property listings table
 * - Commission tracking
 * - Role-based access control
 * 
 * Data Flow:
 * 1. Fetches manager-specific data on mount
 * 2. Updates dashboard metrics in real-time
 * 3. Handles KYC verification workflow
 * 4. Provides quick actions for listing verification
 */

const ManagerDashboard = () => {
  // ================= HOOK INITIALIZATION =================
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  
  // ================= STATE MANAGEMENT =================
  const [listings, setListings] = useState([]);
  const [dashboardStats, setDashboardStats] = useState({
    assignedCount: 0,
    unverifiedCount: 0,
    nearbyCount: 0,
    commissionTotal: 0,
  });
  const [kycStatus, setKycStatus] = useState({
    status: 'Not Submitted',
    color: '#6c757d',
    isSubmitted: false
  });
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // 'all', 'assigned', 'unverified', 'nearby'

  // ================= CONSTANTS =================
  const COMMISSION_RATE = 5000; // ₦5000 per assigned listing
  
  // ================= SIDEBAR MENU ITEMS =================
  const menuItems = [
    { path: '/manager/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/manager/verification', label: 'Verify Listings', icon: '✅' },
    { path: '/manager/profile', label: 'Profile', icon: '👤' },
    { path: '/manager/messages', label: 'View Messages', icon: '💬' },
    { path: '/manager/kyc', label: 'KYC Verification', icon: '📋' },
  ];

  // ================= EFFECT HOOKS =================

  /**
   * useEffect - Initial data loading and permission check
   * Validates manager role and loads dashboard data
   */
  useEffect(() => {
    const checkAccessAndLoadData = async () => {
      // Check if user is authenticated and has manager role
      if (!user) {
        navigate('/login');
        return;
      }
      
      if (user.role !== 'manager') {
        alert('Access denied. Please login as a Manager.');
        navigate('/login');
        return;
      }
      
      await loadDashboardData();
    };
    
    checkAccessAndLoadData();
  }, [user, navigate]);

  // ================= DATA LOADING FUNCTIONS =================

  /**
   * loadDashboardData - Loads all dashboard data including listings and KYC status
   * Simulates API calls with mock data for demonstration
   */
  const loadDashboardData = async () => {
    setIsLoading(true);
    
    try {
      // In production, these would be API calls:
      // const listingsResponse = await fetch('/api/manager/listings');
      // const kycResponse = await fetch('/api/manager/kyc-status');
      
      // Mock data for demonstration
      const mockListings = getMockListings();
      const mockKycStatus = getKycStatus();
      
      setListings(mockListings);
      setKycStatus(mockKycStatus);
      calculateDashboardStats(mockListings);
      
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      alert('Failed to load dashboard data. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * getMockListings - Returns mock listing data for demonstration
   * In production, replace with actual API response
   * @returns {Array} Array of listing objects
   */
  const getMockListings = () => {
    return [
      { 
        id: 1, 
        property: '2BHK Apartment', 
        owner: 'John Doe', 
        status: 'assigned', 
        location: 'Lagos, Ikeja',
        price: '₦850,000/yr',
        lastUpdated: '2024-01-15',
        verificationDue: '2024-01-30',
        image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'
      },
      { 
        id: 2, 
        property: 'Studio Flat', 
        owner: 'Jane Smith', 
        status: 'unverified', 
        location: 'Abuja, Wuse',
        price: '₦450,000/yr',
        lastUpdated: '2024-01-14',
        verificationDue: '2024-01-25',
        image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'
      },
      { 
        id: 3, 
        property: '3BHK Duplex', 
        owner: 'Aliyu Bello', 
        status: 'nearby', 
        location: 'Port Harcourt',
        price: '₦1,200,000/yr',
        lastUpdated: '2024-01-13',
        verificationDue: '2024-01-28',
        image: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'
      },
      { 
        id: 4, 
        property: 'Office Space', 
        owner: 'Tech Corp Ltd', 
        status: 'assigned', 
        location: 'Lagos, VI',
        price: '₦2,500,000/yr',
        lastUpdated: '2024-01-12',
        verificationDue: '2024-02-15',
        image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'
      },
      { 
        id: 5, 
        property: '1BHK Apartment', 
        owner: 'Sarah Johnson', 
        status: 'unverified', 
        location: 'Ibadan',
        price: '₦300,000/yr',
        lastUpdated: '2024-01-11',
        verificationDue: '2024-01-20',
        image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'
      },
    ];
  };

  /**
   * getKycStatus - Retrieves KYC status for current manager
   * Checks localStorage or would call API in production
   * @returns {Object} KYC status object
   */
  const getKycStatus = () => {
    // In production: Check from API or localStorage
    const storedKyc = localStorage.getItem(`kyc_${user?.email}`);
    
    if (storedKyc) {
      const kycData = JSON.parse(storedKyc);
      return {
        status: kycData.status,
        color: getKycColor(kycData.status),
        isSubmitted: true,
        submittedDate: kycData.date
      };
    }
    
    return {
      status: 'Not Submitted',
      color: '#6c757d',
      isSubmitted: false
    };
  };

  /**
   * getKycColor - Returns color code based on KYC status
   * @param {string} status - KYC status string
   * @returns {string} CSS color code
   */
  const getKycColor = (status) => {
    const colors = {
      'approved': '#28a745',    // Green
      'pending': '#ffc107',     // Yellow
      'rejected': '#dc3545',    // Red
      'not_submitted': '#6c757d' // Gray
    };
    
    return colors[status.toLowerCase()] || '#6c757d';
  };

  /**
   * calculateDashboardStats - Calculates dashboard metrics from listings
   * @param {Array} listingsData - Array of listing objects
   */
  const calculateDashboardStats = (listingsData) => {
    const assignedCount = listingsData.filter(l => l.status === 'assigned').length;
    const unverifiedCount = listingsData.filter(l => l.status === 'unverified').length;
    const nearbyCount = listingsData.filter(l => l.status === 'nearby').length;
    const commissionTotal = assignedCount * COMMISSION_RATE;

    setDashboardStats({
      assignedCount,
      unverifiedCount,
      nearbyCount,
      commissionTotal
    });
  };

  // ================= EVENT HANDLERS =================

  /**
   * handleVerifyListing - Navigates to verification page for specific listing
   * @param {number} listingId - ID of listing to verify
   */
  const handleVerifyListing = (listingId) => {
    // Store selected listing for verification page
    localStorage.setItem('selectedListing', listingId);
    navigate('/manager/verification');
  };

  /**
   * handleViewListing - Views details of specific listing
   * @param {Object} listing - Listing object
   */
  const handleViewListing = (listing) => {
    // In production, this would navigate to listing detail page
    alert(`Viewing details for: ${listing.property}\nLocation: ${listing.location}\nPrice: ${listing.price}`);
  };

  /**
   * handleKycAction - Handles KYC verification action
   * Navigates to KYC verification page
   */
  const handleKycAction = () => {
    navigate('/manager/kyc');
  };

  /**
   * handleFilterChange - Filters listings based on status
   * @param {string} statusFilter - Filter type
   */
  const handleFilterChange = (statusFilter) => {
    setFilter(statusFilter);
  };

  /**
   * getFilteredListings - Returns listings filtered by current filter
   * @returns {Array} Filtered listings array
   */
  const getFilteredListings = () => {
    if (filter === 'all') return listings;
    return listings.filter(listing => listing.status === filter);
  };

  /**
   * getStatusBadge - Returns styled badge for listing status
   * @param {string} status - Listing status
   * @returns {JSX.Element} Status badge component
   */
  const getStatusBadge = (status) => {
    const statusConfig = {
      assigned: { label: 'Assigned', color: 'bg-blue-100 text-blue-800' },
      unverified: { label: 'Unverified', color: 'bg-yellow-100 text-yellow-800' },
      nearby: { label: 'Nearby', color: 'bg-purple-100 text-purple-800' },
      verified: { label: 'Verified', color: 'bg-green-100 text-green-800' }
    };
    
    const config = statusConfig[status] || { label: status, color: 'bg-gray-100 text-gray-800' };
    
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${config.color}`}>
        {config.label}
      </span>
    );
  };

  // ================= RENDER COMPONENTS =================

  /**
   * renderDashboardCards - Renders dashboard statistics cards
   * @returns {JSX.Element} Dashboard cards component
   */
  const renderDashboardCards = () => {
    const cards = [
      {
        title: 'Assigned Listings',
        value: dashboardStats.assignedCount,
        icon: '📋',
        color: 'bg-blue-500',
        description: 'Properties assigned to you'
      },
      {
        title: 'Unverified Listings',
        value: dashboardStats.unverifiedCount,
        icon: '⚠️',
        color: 'bg-yellow-500',
        description: 'Require verification'
      },
      {
        title: 'Nearby Properties',
        value: dashboardStats.nearbyCount,
        icon: '📍',
        color: 'bg-purple-500',
        description: 'Properties in your area'
      },
      {
        title: 'Commissions',
        value: `₦${dashboardStats.commissionTotal.toLocaleString()}`,
        icon: '💰',
        color: 'bg-green-500',
        description: 'Total earnings'
      }
    ];

    return (
      <div className="dashboard-cards grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {cards.map((card, index) => (
          <div key={index} className="dashboard-card bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg ${card.color} text-white`}>
                <span className="text-2xl">{card.icon}</span>
              </div>
              <span className="text-sm text-gray-500">{card.description}</span>
            </div>
            <h3 className="text-gray-500 text-sm font-medium mb-2">{card.title}</h3>
            <p className="text-3xl font-bold text-gray-800">{card.value}</p>
          </div>
        ))}
      </div>
    );
  };

  /**
   * renderListingsTable - Renders listings table with actions
   * @returns {JSX.Element} Listings table component
   */
  const renderListingsTable = () => {
    const filteredListings = getFilteredListings();

    if (filteredListings.length === 0) {
      return (
        <div className="text-center py-12">
          <div className="text-gray-400 text-6xl mb-4">🏠</div>
          <h3 className="text-xl font-semibold text-gray-700 mb-2">No listings found</h3>
          <p className="text-gray-500">No properties match your current filter</p>
        </div>
      );
    }

    return (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Property
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Owner
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Location
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Price
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredListings.map((listing) => (
              <tr key={listing.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10">
                      <img
                        className="h-10 w-10 rounded-lg object-cover"
                        src={listing.image}
                        alt={listing.property}
                      />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">
                        {listing.property}
                      </div>
                      <div className="text-sm text-gray-500">
                        Due: {listing.verificationDue}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm text-gray-900">{listing.owner}</div>
                </td>
                <td className="px-6 py-4">
                  {getStatusBadge(listing.status)}
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm text-gray-900">{listing.location}</div>
                  <div className="text-sm text-gray-500">Updated: {listing.lastUpdated}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm font-semibold text-gray-900">{listing.price}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex space-x-2">
                    {listing.status === 'unverified' && (
                      <button
                        onClick={() => handleVerifyListing(listing.id)}
                        className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-white bg-yellow-600 hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500"
                      >
                        Verify
                      </button>
                    )}
                    <button
                      onClick={() => handleViewListing(listing)}
                      className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      View
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  // ================= MAIN RENDER =================

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="flex">
        {/* Sidebar */}
        <Sidebar menuItems={menuItems} activePath="/manager/dashboard" />
        
        {/* Main Content */}
        <main className="flex-1 p-6 lg:p-8">
          {/* Welcome Header */}
          <div className="mb-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  Welcome, {user?.name || 'Manager'}
                </h1>
                <p className="text-gray-600">
                  Overview of your assigned listings and activities
                </p>
              </div>
              
              {/* User Info & KYC Status */}
              <div className="mt-4 lg:mt-0">
                <div className="flex items-center space-x-4">
                  <div className="user-info-card bg-white rounded-lg shadow-sm p-4 flex items-center space-x-4">
                    <img
                      src={user?.avatar || '/images/default-avatar.png'}
                      alt={user?.name || 'Manager'}
                      className="h-12 w-12 rounded-full border-2 border-gray-200"
                    />
                    <div>
                      <p className="font-medium text-gray-900">{user?.name || 'Manager'}</p>
                      <p className="text-sm text-gray-500">{user?.email || 'manager@example.com'}</p>
                    </div>
                  </div>
                  
                  {/* KYC Status Card */}
                  <div className="kyc-status-card bg-white rounded-lg shadow-sm p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-500">KYC Status</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <span
                            className="inline-block w-3 h-3 rounded-full"
                            style={{ backgroundColor: kycStatus.color }}
                          ></span>
                          <span className="font-semibold capitalize">
                            {kycStatus.status.replace('_', ' ')}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={handleKycAction}
                        className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                      >
                        {kycStatus.isSubmitted ? 'View Status' : 'Submit KYC'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Dashboard Cards */}
          {renderDashboardCards()}
          
          {/* Listings Section */}
          <section className="bg-white rounded-xl shadow-md overflow-hidden">
            {/* Section Header */}
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-gray-800">Property Listings</h2>
                  <p className="text-gray-600 text-sm mt-1">
                    Manage and verify property listings assigned to you
                  </p>
                </div>
                
                {/* Filter Tabs */}
                <div className="mt-4 sm:mt-0">
                  <div className="inline-flex rounded-lg border border-gray-200 p-1">
                    {['all', 'assigned', 'unverified', 'nearby'].map((filterType) => (
                      <button
                        key={filterType}
                        onClick={() => handleFilterChange(filterType)}
                        className={`px-4 py-2 text-sm font-medium rounded-md capitalize ${
                          filter === filterType
                            ? 'bg-blue-600 text-white'
                            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                        }`}
                      >
                        {filterType === 'all' ? 'All Listings' : filterType}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Listings Table */}
            <div className="p-6">
              {renderListingsTable()}
            </div>
          </section>
          
          {/* Quick Actions Footer */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-blue-50 rounded-xl p-6">
              <h3 className="font-semibold text-blue-800 mb-2">Need Help?</h3>
              <p className="text-blue-600 text-sm mb-4">
                Contact support for assistance with listings or verification
              </p>
              <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                Contact Support →
              </button>
            </div>
            <div className="bg-green-50 rounded-xl p-6">
              <h3 className="font-semibold text-green-800 mb-2">Quick Actions</h3>
              <div className="space-y-2">
                <button
                  onClick={() => navigate('/manager/verification')}
                  className="block w-full text-left text-green-600 hover:text-green-800 text-sm p-2 hover:bg-green-100 rounded"
                >
                  ⚡ Verify Pending Listings
                </button>
                <button
                  onClick={() => navigate('/manager/messages')}
                  className="block w-full text-left text-green-600 hover:text-green-800 text-sm p-2 hover:bg-green-100 rounded"
                >
                  💬 Check Messages
                </button>
              </div>
            </div>
            <div className="bg-purple-50 rounded-xl p-6">
              <h3 className="font-semibold text-purple-800 mb-2">Statistics</h3>
              <p className="text-purple-600 text-sm">
                You've verified <strong>{dashboardStats.assignedCount}</strong> properties this month
              </p>
              <div className="mt-4 h-2 bg-purple-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-600 rounded-full"
                  style={{ width: `${Math.min((dashboardStats.assignedCount / 10) * 100, 100)}%` }}
                ></div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ManagerDashboard;