import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, Building, Briefcase, DollarSign, 
  MessageSquare, Settings, Users, BarChart
} from 'lucide-react';
import './EstateNav.css';

const EstateNav = () => {
  const location = useLocation();
  
  const navItems = [
    { path: '/dashboard/estate', icon: Home, label: 'Overview' },
    { path: '/dashboard/estate/portfolio', icon: Building, label: 'Portfolio' },
    { path: '/dashboard/estate/services', icon: Briefcase, label: 'Services' },
    { path: '/dashboard/estate/clients', icon: Users, label: 'Clients' },
    { path: '/dashboard/estate/financial', icon: DollarSign, label: 'Financial' },
    { path: '/dashboard/estate/analytics', icon: BarChart, label: 'Analytics' },
    { path: '/dashboard/estate/messages', icon: MessageSquare, label: 'Messages' },
    { path: '/dashboard/estate/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="estate-nav">
      <div className="nav-header">
        <h3>Estate Firm</h3>
        <p className="nav-subtitle">Management Dashboard</p>
      </div>
      
      <nav className="nav-menu">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`nav-item ${isActive ? 'active' : ''}`}
            >
              <Icon size={20} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>
      
      <div className="nav-footer">
        <button className="btn btn-primary">
          <Building size={18} />
          Post Property
        </button>
        <button className="btn btn-outline">
          <Briefcase size={18} />
          Post Service
        </button>
      </div>
    </div>
  );
};

export default EstateNav;