import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Building, MapPin, Phone, Mail, Globe, 
  Star, Users, Home, CheckCircle, Calendar,
  DollarSign, FileText, AlertCircle, ArrowLeft,
  Shield, TrendingUp, Clock, MessageSquare,
  ExternalLink, Award, Briefcase, Heart
} from 'lucide-react';
import './EstateProfilePage.css';

const EstateProfilePage = () => {
  const { firmId } = useParams();
  const [firm, setFirm] = useState(null);
  const [listings, setListings] = useState([]);
  const [services, setServices] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Mock data for testing
    const mockFirm = {
      id: firmId,
      name: 'Premium Real Estate Group',
      tagline: 'Your Trusted Property Partner',
      description: 'A leading real estate agency with over 15 years of experience specializing in luxury properties, commercial spaces, and residential rentals. We provide comprehensive property management and real estate services across Lagos and Abuja.',
      logo: null,
      coverImage: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1200',
      rating: 4.8,
      totalReviews: 247,
      yearsExperience: 15,
      propertiesManaged: 156,
      teamSize: 24,
      contact: {
        phone: '+234 801 234 5678',
        email: 'info@premiumrealestate.com',
        website: 'www.premiumrealestate.com',
        address: '123 Business District, Victoria Island, Lagos'
      },
      specialties: [
        'Luxury Apartments',
        'Commercial Spaces',
        'Property Management',
        'Tenant Screening',
        'Property Valuation',
        'Legal Services'
      ],
      verified: true,
      memberSince: '2010',
      licenseNumber: 'RE-LAG-123456',
      awards: [
        'Best Real Estate Agency 2023',
        'Top Property Manager 2022',
        'Excellence in Customer Service 2021'
      ],
      languages: ['English', 'Yoruba', 'Igbo', 'Hausa'],
      responseTime: '2 hours',
      serviceAreas: ['Lagos', 'Abuja', 'Port Harcourt', 'Ibadan']
    };

    const mockListings = [
      {
        id: 'list_001',
        title: '3-Bedroom Luxury Penthouse, Lekki Phase 1',
        type: 'Apartment',
        price: 25000000,
        pricePeriod: 'yearly',
        status: 'available',
        location: 'Lekki, Lagos',
        bedrooms: 3,
        bathrooms: 4,
        area: '3500 sq ft',
        features: ['Swimming Pool', 'Gym', '24/7 Security', 'Parking'],
        postedDate: '2024-11-15'
      },
      {
        id: 'list_002',
        title: 'Modern Office Space, Victoria Island',
        type: 'Commercial',
        price: 15000000,
        pricePeriod: 'yearly',
        status: 'available',
        location: 'Victoria Island, Lagos',
        area: '5000 sq ft',
        features: ['High-Speed Internet', 'Meeting Rooms', 'Reception'],
        postedDate: '2024-11-10'
      }
    ];

    const mockServices = [
      {
        id: 'svc_001',
        title: 'Property Management Services',
        description: 'Complete property management including tenant screening, rent collection, and maintenance coordination.',
        price: '10-15% of monthly rent',
        rating: 4.8,
        reviews: 42
      },
      {
        id: 'svc_002',
        title: 'Real Estate Valuation',
        description: 'Professional property valuation for sales, purchase, or insurance purposes.',
        price: '₦50,000 - ₦200,000',
        rating: 4.9,
        reviews: 28
      }
    ];

    const mockReviews = [
      {
        id: 'rev_001',
        userName: 'Michael Johnson',
        userRole: 'Property Owner',
        rating: 5,
        date: '2024-11-05',
        comment: 'Excellent service! They helped me find the perfect office space for my startup. Very professional and responsive throughout the process.',
        property: 'Office Space, VI'
      },
      {
        id: 'rev_002',
        userName: 'Sarah Williams',
        userRole: 'Tenant',
        rating: 4,
        date: '2024-10-28',
        comment: 'Great experience renting through them. The process was smooth and transparent. Highly recommended!',
        property: 'Luxury Apartment, Ikoyi'
      }
    ];

    setTimeout(() => {
      setFirm(mockFirm);
      setListings(mockListings);
      setServices(mockServices);
      setReviews(mockReviews);
      setLoading(false);
    }, 1000);
  }, [firmId]);

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading estate firm profile...</p>
      </div>
    );
  }

  if (!firm) {
    return (
      <div className="error-container">
        <AlertCircle size={48} />
        <h2>Estate Firm Not Found</h2>
        <p>The firm you're looking for doesn't exist or has been removed.</p>
        <Link to="/" className="btn btn-primary">
          <ArrowLeft size={18} />
          Back to Home
        </Link>
      </div>
    );
  }

  const formatPrice = (price) => {
    return `₦${price.toLocaleString()}`;
  };

  return (
    <div className="estate-profile-page">
      {/* Cover Image */}
      <div className="cover-section">
        <div 
          className="cover-image"
          style={{ backgroundImage: `url(${firm.coverImage})` }}
        >
          <div className="cover-overlay"></div>
        </div>
        
        <div className="profile-header">
          <div className="profile-avatar">
            {firm.logo ? (
              <img src={firm.logo} alt={firm.name} />
            ) : (
              <Building size={48} />
            )}
          </div>
          
          <div className="profile-info">
            <div className="profile-title">
              <h1>{firm.name}</h1>
              {firm.verified && (
                <div className="verified-badge">
                  <CheckCircle size={16} />
                  <span>Verified Firm</span>
                </div>
              )}
            </div>
            
            <p className="tagline">{firm.tagline}</p>
            
            <div className="profile-stats">
              <div className="stat">
                <Star size={18} />
                <span>{firm.rating} ({firm.totalReviews} reviews)</span>
              </div>
              <div className="stat">
                <Building size={18} />
                <span>{firm.propertiesManaged} properties managed</span>
              </div>
              <div className="stat">
                <Calendar size={18} />
                <span>{firm.yearsExperience} years experience</span>
              </div>
            </div>
          </div>
          
          <div className="profile-actions">
            <button className="btn btn-primary">
              <MessageSquare size={18} />
              Contact Firm
            </button>
            <button className="btn btn-outline">
              <Heart size={18} />
              Save Firm
            </button>
          </div>
        </div>
      </div>

      <div className="profile-content">
        <div className="main-content">
          {/* About Section */}
          <div className="content-section">
            <h2>About Us</h2>
            <p className="description">{firm.description}</p>
            
            <div className="specialties">
              <h3>Specialties</h3>
              <div className="specialties-list">
                {firm.specialties.map((specialty, index) => (
                  <div key={index} className="specialty-tag">
                    <Briefcase size={14} />
                    {specialty}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Listings Section */}
          <div className="content-section">
            <div className="section-header">
              <h2>Current Listings</h2>
              <Link to="/listings" className="view-all">
                View All <ExternalLink size={14} />
              </Link>
            </div>
            
            <div className="listings-grid">
              {listings.map(listing => (
                <div key={listing.id} className="listing-card">
                  <div className="listing-image">
                    <div className="listing-type">{listing.type}</div>
                  </div>
                  <div className="listing-details">
                    <h3>{listing.title}</h3>
                    <p className="location">
                      <MapPin size={14} />
                      {listing.location}
                    </p>
                    <div className="listing-features">
                      {listing.bedrooms && <span>🛏️ {listing.bedrooms} beds</span>}
                      {listing.bathrooms && <span>🚿 {listing.bathrooms} baths</span>}
                      {listing.area && <span>📐 {listing.area}</span>}
                    </div>
                    <div className="listing-footer">
                      <span className="price">{formatPrice(listing.price)}/{listing.pricePeriod}</span>
                      <button className="btn btn-sm">View Details</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Services Section */}
          <div className="content-section">
            <div className="section-header">
              <h2>Services Offered</h2>
              <Link to="/services" className="view-all">
                View All <ExternalLink size={14} />
              </Link>
            </div>
            
            <div className="services-grid">
              {services.map(service => (
                <div key={service.id} className="service-card">
                  <div className="service-header">
                    <Briefcase size={20} />
                    <div className="service-rating">
                      <Star size={14} />
                      <span>{service.rating} ({service.reviews})</span>
                    </div>
                  </div>
                  <h3>{service.title}</h3>
                  <p className="service-description">{service.description}</p>
                  <div className="service-footer">
                    <span className="price">{service.price}</span>
                    <button className="btn btn-sm">Learn More</button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Reviews Section */}
          <div className="content-section">
            <h2>Client Reviews</h2>
            <div className="reviews-list">
              {reviews.map(review => (
                <div key={review.id} className="review-card">
                  <div className="review-header">
                    <div className="reviewer-info">
                      <div className="avatar">
                        {review.userName.charAt(0)}
                      </div>
                      <div>
                        <h4>{review.userName}</h4>
                        <p className="user-role">{review.userRole}</p>
                      </div>
                    </div>
                    <div className="review-rating">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i}
                          size={16}
                          fill={i < review.rating ? "#FFD700" : "none"}
                          stroke={i < review.rating ? "#FFD700" : "#ccc"}
                        />
                      ))}
                      <span className="review-date">{review.date}</span>
                    </div>
                  </div>
                  <p className="review-comment">{review.comment}</p>
                  {review.property && (
                    <div className="review-property">
                      <Home size={14} />
                      <span>{review.property}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="sidebar">
          {/* Contact Info */}
          <div className="sidebar-card">
            <h3>Contact Information</h3>
            <div className="contact-info">
              <div className="contact-item">
                <Phone size={16} />
                <a href={`tel:${firm.contact.phone}`}>{firm.contact.phone}</a>
              </div>
              <div className="contact-item">
                <Mail size={16} />
                <a href={`mailto:${firm.contact.email}`}>{firm.contact.email}</a>
              </div>
              <div className="contact-item">
                <Globe size={16} />
                <a href={`https://${firm.contact.website}`} target="_blank" rel="noopener noreferrer">
                  {firm.contact.website}
                </a>
              </div>
              <div className="contact-item">
                <MapPin size={16} />
                <span>{firm.contact.address}</span>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="sidebar-card">
            <h3>Firm Stats</h3>
            <div className="firm-stats">
              <div className="stat-item">
                <Users size={20} />
                <div>
                  <span className="stat-value">{firm.teamSize}</span>
                  <span className="stat-label">Team Members</span>
                </div>
              </div>
              <div className="stat-item">
                <TrendingUp size={20} />
                <div>
                  <span className="stat-value">96%</span>
                  <span className="stat-label">Response Rate</span>
                </div>
              </div>
              <div className="stat-item">
                <Clock size={20} />
                <div>
                  <span className="stat-value">{firm.responseTime}</span>
                  <span className="stat-label">Avg. Response Time</span>
                </div>
              </div>
            </div>
          </div>

          {/* Service Areas */}
          <div className="sidebar-card">
            <h3>Service Areas</h3>
            <div className="service-areas-list">
              {firm.serviceAreas.map((area, index) => (
                <span key={index} className="area-tag">
                  <MapPin size={12} />
                  {area}
                </span>
              ))}
            </div>
          </div>

          {/* Awards */}
          {firm.awards && firm.awards.length > 0 && (
            <div className="sidebar-card">
              <h3>Awards & Recognition</h3>
              <div className="awards-list">
                {firm.awards.map((award, index) => (
                  <div key={index} className="award-item">
                    <Award size={16} />
                    <span>{award}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* License */}
          <div className="sidebar-card">
            <h3>Licensing</h3>
            <div className="license-info">
              <Shield size={16} />
              <div>
                <span className="license-number">{firm.licenseNumber}</span>
                <span className="member-since">Member since {firm.memberSince}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EstateProfilePage;