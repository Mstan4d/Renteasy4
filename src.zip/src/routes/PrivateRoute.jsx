// Add this to debug your AuthContext
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../shared/context/AuthContext';

const PrivateRoute = ({ children, allowedRoles = [], ...props }) => {
  const { user, loading } = useAuth();
  
  // Add debugging
  console.log('PrivateRoute - Loading:', loading);
  console.log('PrivateRoute - User:', user);
  console.log('PrivateRoute - User Role:', user?.role);
  console.log('PrivateRoute - Allowed Roles:', allowedRoles);
  
  if (loading) {
    console.log('PrivateRoute: Still loading auth state');
    return <div className="loading">Loading...</div>;
  }

  if (!user) {
    console.log('PrivateRoute: No user found, redirecting to login');
    return <Navigate to="/login" replace />;
  }

  // Check role-based access
  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    console.log(`PrivateRoute: User role ${user.role} not in ${allowedRoles}, redirecting to /dashboard`);
    return <Navigate to="/dashboard" replace />;
  }

  console.log('PrivateRoute: Access granted');
  // If children is a function (render prop), pass user to it
  if (typeof children === 'function') {
    return children({ user });
  }

  // Otherwise, just render children
  return children;
};

export default PrivateRoute;