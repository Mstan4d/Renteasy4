import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Calendar,
  Clock,
  MapPin,
  User,
  Phone,
  Mail,
  Home,
  DollarSign,
  CheckCircle,
  XCircle,
  AlertCircle,
  MessageCircle,
  FileText,
  CreditCard,
  Shield,
  Star,
  ChevronLeft,
  Download,
  Printer,
  Edit,
  MoreVertical,
  Navigation,
  ClipboardCheck,
  Truck
} from 'lucide-react';
import './ProviderBookings.css'

const ProviderBookings = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('details');
  const [showActionsMenu, setShowActionsMenu] = useState(false);
  const [statusUpdate, setStatusUpdate] = useState('');
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });

  // Mock data - replace with API call
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      const mockBooking = {
        id: id || 'BOOK-789456',
        bookingNumber: 'BK-2024-00123',
        serviceName: 'Deep Cleaning Service',
        serviceType: 'Cleaning',
        serviceCategory: 'Home Services',
        customer: {
          id: 'CUST-456',
          name: 'Adebayo Johnson',
          role: 'tenant',
          email: 'adebayo.j@example.com',
          phone: '+2348012345678',
          avatar: null,
          rating: 4.5,
          completedBookings: 12
        },
        property: {
          id: 'PROP-789',
          address: '24, Allen Avenue, Ikeja, Lagos',
          type: '3-Bedroom Apartment',
          size: '1800 sq ft'
        },
        dateTime: {
          scheduled: '2024-01-28T14:00:00Z',
          requested: '2024-01-20T10:30:00Z',
          accepted: '2024-01-20T11:15:00Z',
          completed: null,
          cancelled: null
        },
        pricing: {
          basePrice: 35000,
          extraCharges: [
            { description: 'Window Cleaning', amount: 5000 },
            { description: 'Furniture Movement', amount: 3000 }
          ],
          discount: 2000,
          tax: 1750,
          total: 40750,
          paymentMethod: 'card',
          paymentStatus: 'paid',
          paymentId: 'PAY-789123456'
        },
        status: 'scheduled',
        statusHistory: [
          { status: 'requested', timestamp: '2024-01-20T10:30:00Z', note: 'Booking requested by customer' },
          { status: 'accepted', timestamp: '2024-01-20T11:15:00Z', note: 'Booking accepted by provider' },
          { status: 'confirmed', timestamp: '2024-01-20T12:00:00Z', note: 'Payment received and confirmed' }
        ],
        notes: 'Customer requested eco-friendly cleaning products. Please avoid strong chemicals.',
        specialInstructions: 'Parking available at the back. Bring extra cleaning cloths.',
        team: [
          { id: 'TM-001', name: 'Chika Okafor', role: 'Lead Cleaner', phone: '+2348023456789' },
          { id: 'TM-002', name: 'Bola Ahmed', role: 'Assistant Cleaner', phone: '+2348034567890' }
        ],
        duration: '4 hours',
        materialsNeeded: ['Eco-friendly detergent', 'Microfiber cloths', 'Vacuum cleaner', 'Mop'],
        documents: [
          { id: 'DOC-001', name: 'Service Agreement.pdf', url: '#', uploaded: '2024-01-20T11:30:00Z' },
          { id: 'DOC-002', name: 'Customer Requirements.docx', url: '#', uploaded: '2024-01-20T11:45:00Z' }
        ],
        messages: [
          { id: 'MSG-001', sender: 'customer', text: 'Hello, I need deep cleaning for my new apartment', timestamp: '2024-01-20T10:30:00Z' },
          { id: 'MSG-002', sender: 'provider', text: 'Sure! I can schedule it for next Monday at 2 PM', timestamp: '2024-01-20T10:45:00Z' },
          { id: 'MSG-003', sender: 'customer', text: 'Perfect! Please use eco-friendly products', timestamp: '2024-01-20T11:00:00Z' }
        ],
        review: null,
        cancellationPolicy: {
          allowed: true,
          deadline: '2024-01-27T14:00:00Z',
          refundPercentage: 80
        },
        commissionNote: 'This booking counts toward your 10 free bookings limit. After 10 bookings, ₦3,000 monthly subscription applies.'
      };
      setBooking(mockBooking);
      setLoading(false);
    }, 1000);
  }, [id]);

  const getStatusBadge = (status) => {
    const config = {
      requested: { color: 'bg-yellow-100 text-yellow-800', label: 'Requested', icon: <Clock className="w-4 h-4" /> },
      accepted: { color: 'bg-blue-100 text-blue-800', label: 'Accepted', icon: <CheckCircle className="w-4 h-4" /> },
      confirmed: { color: 'bg-green-100 text-green-800', label: 'Confirmed', icon: <CheckCircle className="w-4 h-4" /> },
      scheduled: { color: 'bg-purple-100 text-purple-800', label: 'Scheduled', icon: <Calendar className="w-4 h-4" /> },
      in_progress: { color: 'bg-orange-100 text-orange-800', label: 'In Progress', icon: <Clock className="w-4 h-4" /> },
      completed: { color: 'bg-green-100 text-green-800', label: 'Completed', icon: <CheckCircle className="w-4 h-4" /> },
      cancelled: { color: 'bg-red-100 text-red-800', label: 'Cancelled', icon: <XCircle className="w-4 h-4" /> },
      rejected: { color: 'bg-gray-100 text-gray-800', label: 'Rejected', icon: <XCircle className="w-4 h-4" /> }
    };
    
    const { color, label, icon } = config[status] || config.requested;
    
    return (
      <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${color}`}>
        {icon}
        {label}
      </span>
    );
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-NG', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const formatDateTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-NG', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-NG', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const calculateTimeRemaining = (dateString) => {
    const now = new Date();
    const target = new Date(dateString);
    const diff = target - now;
    
    if (diff <= 0) return 'Expired';
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) return `${days}d ${hours}h`;
    return `${hours}h`;
  };

  const handleStatusUpdate = (newStatus) => {
    if (statusUpdate) {
      // In real app, make API call here
      const updatedBooking = {
        ...booking,
        status: newStatus,
        statusHistory: [
          ...booking.statusHistory,
          {
            status: newStatus,
            timestamp: new Date().toISOString(),
            note: statusUpdate
          }
        ]
      };
      
      if (newStatus === 'completed') {
        updatedBooking.dateTime.completed = new Date().toISOString();
      } else if (newStatus === 'cancelled') {
        updatedBooking.dateTime.cancelled = new Date().toISOString();
      }
      
      setBooking(updatedBooking);
      setStatusUpdate('');
      alert(`Booking status updated to ${newStatus}`);
    }
  };

  const handleSendMessage = () => {
    navigate(`/dashboard/provider/messages?booking=${booking.id}`);
  };

  const handleDownloadInvoice = () => {
    // Generate and download invoice
    alert('Invoice download functionality would be implemented here');
  };

  const handleSubmitReview = () => {
    const updatedBooking = {
      ...booking,
      review: {
        ...newReview,
        timestamp: new Date().toISOString(),
        reviewer: 'provider'
      }
    };
    setBooking(updatedBooking);
    setShowReviewModal(false);
    setNewReview({ rating: 5, comment: '' });
    alert('Review submitted successfully');
  };

  const handlePrintDetails = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="provider-bookings-container">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading booking details...</p>
        </div>
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Booking not found</h3>
          <p className="text-gray-600 mb-6">The requested booking could not be found</p>
          <Link
            to="/dashboard/provider/bookings"
            className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            Back to Bookings
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="provider-bookings-container">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/dashboard/provider/bookings')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </button>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900">
                  Booking #{booking.bookingNumber}
                </h1>
                <p className="text-gray-600 mt-1">{booking.serviceName}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {getStatusBadge(booking.status)}
              
              <div className="relative">
                <button
                  onClick={() => setShowActionsMenu(!showActionsMenu)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <MoreVertical className="w-5 h-5 text-gray-600" />
                </button>
                
                {showActionsMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 z-10">
                    <button
                      onClick={handlePrintDetails}
                      className="flex items-center gap-3 w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                    >
                      <Printer className="w-4 h-4 text-gray-600" />
                      Print Details
                    </button>
                    <button
                      onClick={handleDownloadInvoice}
                      className="flex items-center gap-3 w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                    >
                      <Download className="w-4 h-4 text-gray-600" />
                      Download Invoice
                    </button>
                    <button
                      onClick={() => navigate(`/dashboard/provider/bookings/${booking.id}/edit`)}
                      className="flex items-center gap-3 w-full px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                    >
                      <Edit className="w-4 h-4 text-gray-600" />
                      Edit Booking
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Booking Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Amount</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(booking.pricing.total)}</p>
                </div>
                <div className="p-3 bg-green-100 rounded-lg">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </div>
            
            <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Scheduled Date</p>
                  <p className="text-lg font-bold text-gray-900">{formatDate(booking.dateTime.scheduled)}</p>
                </div>
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Calendar className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </div>
            
            <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Duration</p>
                  <p className="text-lg font-bold text-gray-900">{booking.duration}</p>
                </div>
                <div className="p-3 bg-purple-100 rounded-lg">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </div>
            
            <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Time Remaining</p>
                  <p className="text-lg font-bold text-gray-900">
                    {calculateTimeRemaining(booking.dateTime.scheduled)}
                  </p>
                </div>
                <div className="p-3 bg-orange-100 rounded-lg">
                  <Clock className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Main Content */}
        <div className="provider-bookings-container">
          {/* Left Column - Booking Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Tabs */}
            <div className="provider-bookings-container">
              <div className="border-b border-gray-200">
                <nav className="flex overflow-x-auto">
                  {['details', 'messages', 'documents', 'team', 'history'].map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`flex-shrink-0 px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                        activeTab === tab
                          ? 'border-blue-600 text-blue-600'
                          : 'border-transparent text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      {tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </button>
                  ))}
                </nav>
              </div>
              
              <div className="p-6">
                {/* Details Tab */}
                {activeTab === 'details' && (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Service Details</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-600">Service Type:</span>
                          <span className="font-medium">{booking.serviceType}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-gray-600">Category:</span>
                          <span className="font-medium">{booking.serviceCategory}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-gray-600">Duration:</span>
                          <span className="font-medium">{booking.duration}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border-t border-gray-200 pt-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Customer Instructions</h3>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <p className="text-gray-700">{booking.notes}</p>
                        {booking.specialInstructions && (
                          <div className="mt-3">
                            <p className="text-sm font-medium text-gray-900 mb-1">Special Instructions:</p>
                            <p className="text-gray-700">{booking.specialInstructions}</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="border-t border-gray-200 pt-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Materials Required</h3>
                      <div className="flex flex-wrap gap-2">
                        {booking.materialsNeeded.map((material, index) => (
                          <span
                            key={index}
                            className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm"
                          >
                            {material}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Messages Tab */}
                {activeTab === 'messages' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-gray-900">Booking Messages</h3>
                      <button
                        onClick={handleSendMessage}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <MessageCircle className="w-4 h-4" />
                        Send Message
                      </button>
                    </div>
                    
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {booking.messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.sender === 'provider' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-md rounded-lg p-4 ${
                              message.sender === 'provider'
                                ? 'bg-blue-100 text-blue-900'
                                : 'bg-gray-100 text-gray-900'
                            }`}
                          >
                            <p>{message.text}</p>
                            <p className="text-xs mt-2 opacity-70">
                              {formatDateTime(message.timestamp)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Documents Tab */}
                {activeTab === 'documents' && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Booking Documents</h3>
                    <div className="space-y-3">
                      {booking.documents.map((doc) => (
                        <div
                          key={doc.id}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <FileText className="w-5 h-5 text-gray-500" />
                            <div>
                              <p className="font-medium text-gray-900">{doc.name}</p>
                              <p className="text-sm text-gray-600">
                                Uploaded: {formatDate(doc.uploaded)}
                              </p>
                            </div>
                          </div>
                          <button className="text-blue-600 hover:text-blue-800">
                            Download
                          </button>
                        </div>
                      ))}
                    </div>
                    
                    <button className="mt-4 inline-flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                      <FileText className="w-4 h-4" />
                      Upload New Document
                    </button>
                  </div>
                )}
                
                {/* Team Tab */}
                {activeTab === 'team' && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Assigned Team</h3>
                    <div className="space-y-4">
                      {booking.team.map((member) => (
                        <div
                          key={member.id}
                          className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                              <User className="w-6 h-6 text-blue-600" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{member.name}</p>
                              <p className="text-sm text-gray-600">{member.role}</p>
                              <p className="text-sm text-gray-600">{member.phone}</p>
                            </div>
                          </div>
                          <button className="text-blue-600 hover:text-blue-800">
                            <MessageCircle className="w-5 h-5" />
                          </button>
                        </div>
                      ))}
                    </div>
                    
                    <button className="mt-4 inline-flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                      <User className="w-4 h-4" />
                      Assign Team Member
                    </button>
                  </div>
                )}
                
                {/* History Tab */}
                {activeTab === 'history' && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Status History</h3>
                    <div className="space-y-4">
                      {booking.statusHistory.map((entry, index) => (
                        <div key={index} className="flex items-start gap-4">
                          <div className="flex-shrink-0 w-2 h-2 mt-2 bg-blue-600 rounded-full"></div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <span className="font-medium text-gray-900">
                                {entry.status.charAt(0).toUpperCase() + entry.status.slice(1)}
                              </span>
                              <span className="text-sm text-gray-600">
                                {formatDateTime(entry.timestamp)}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">{entry.note}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Status Update Section */}
            {['scheduled', 'accepted', 'confirmed'].includes(booking.status) && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Update Booking Status</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Status Note
                    </label>
                    <textarea
                      value={statusUpdate}
                      onChange={(e) => setStatusUpdate(e.target.value)}
                      placeholder="Add notes about the status update..."
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      rows="3"
                    />
                  </div>
                  
                  <div className="flex flex-wrap gap-3">
                    {booking.status === 'scheduled' && (
                      <button
                        onClick={() => handleStatusUpdate('in_progress')}
                        className="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                      >
                        Start Service
                      </button>
                    )}
                    
                    {booking.status === 'in_progress' && (
                      <button
                        onClick={() => handleStatusUpdate('completed')}
                        className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                      >
                        Mark as Completed
                      </button>
                    )}
                    
                    <button
                      onClick={() => handleStatusUpdate('cancelled')}
                      className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                    >
                      Cancel Booking
                    </button>
                    
                    <button
                      onClick={() => setStatusUpdate('')}
                      className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      Clear
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Right Column - Sidebar */}
          <div className="space-y-6">
            {/* Customer Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <User className="w-5 h-5" />
                Customer Details
              </h3>
              
              <div className="space-y-4">
                <div>
                  <p className="font-medium text-gray-900">{booking.customer.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">
                      {booking.customer.role}
                    </span>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-sm text-gray-700">{booking.customer.rating}</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <a href={`tel:${booking.customer.phone}`} className="text-gray-700 hover:text-blue-600">
                      {booking.customer.phone}
                    </a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 text-gray-500" />
                    <a href={`mailto:${booking.customer.email}`} className="text-gray-700 hover:text-blue-600">
                      {booking.customer.email}
                    </a>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-gray-200">
                  <p className="text-sm text-gray-600">
                    Completed Bookings: <span className="font-medium">{booking.customer.completedBookings}</span>
                  </p>
                </div>
                
                <div className="flex gap-3">
                  <button
                    onClick={handleSendMessage}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Message
                  </button>
                  <button className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                    <Phone className="w-4 h-4" />
                    Call
                  </button>
                </div>
              </div>
            </div>
            
            {/* Property Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Home className="w-5 h-5" />
                Property Details
              </h3>
              
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-gray-500 mt-1 flex-shrink-0" />
                  <p className="text-gray-700">{booking.property.address}</p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Type:</span>
                    <span className="font-medium">{booking.property.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Size:</span>
                    <span className="font-medium">{booking.property.size}</span>
                  </div>
                </div>
                
                <button className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                  <Navigation className="w-4 h-4" />
                  Get Directions
                </button>
              </div>
            </div>
            
            {/* Pricing Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Pricing Breakdown
              </h3>
              
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Base Price:</span>
                  <span className="font-medium">{formatCurrency(booking.pricing.basePrice)}</span>
                </div>
                
                {booking.pricing.extraCharges.map((charge, index) => (
                  <div key={index} className="flex justify-between">
                    <span className="text-gray-600">{charge.description}:</span>
                    <span className="font-medium">{formatCurrency(charge.amount)}</span>
                  </div>
                ))}
                
                {booking.pricing.discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount:</span>
                    <span>-{formatCurrency(booking.pricing.discount)}</span>
                  </div>
                )}
                
                {booking.pricing.tax > 0 && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tax:</span>
                    <span className="font-medium">{formatCurrency(booking.pricing.tax)}</span>
                  </div>
                )}
                
                <div className="pt-3 border-t border-gray-200">
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total:</span>
                    <span>{formatCurrency(booking.pricing.total)}</span>
                  </div>
                </div>
                
                <div className="pt-3 border-t border-gray-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Payment Status:</span>
                    <span className={`px-2 py-1 rounded text-sm font-medium ${
                      booking.pricing.paymentStatus === 'paid'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {booking.pricing.paymentStatus}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Method:</span>
                    <div className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-gray-500" />
                      <span className="font-medium capitalize">{booking.pricing.paymentMethod}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <button
                onClick={handleDownloadInvoice}
                className="w-full mt-4 inline-flex items-center justify-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <Download className="w-4 h-4" />
                Download Invoice
              </button>
            </div>
            
            {/* Commission Note */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm text-yellow-800">{booking.commissionNote}</p>
                  <Link
                    to="/dashboard/provider/subscription"
                    className="inline-block mt-2 text-sm font-medium text-yellow-700 hover:text-yellow-900"
                  >
                    View subscription details →
                  </Link>
                </div>
              </div>
            </div>
            
            {/* Review Section */}
            {booking.status === 'completed' && !booking.review && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Leave a Review</h3>
                <p className="text-gray-600 mb-4">Share your experience working with this customer</p>
                <button
                  onClick={() => setShowReviewModal(true)}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Star className="w-4 h-4" />
                  Write Review
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full">
            <div className="p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Review Customer</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Rating
                  </label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewReview({ ...newReview, rating: star })}
                        className="p-1"
                      >
                        <Star
                          className={`w-8 h-8 ${
                            star <= newReview.rating
                              ? 'text-yellow-500 fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Comments
                  </label>
                  <textarea
                    value={newReview.comment}
                    onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                    placeholder="Share your experience working with this customer..."
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    rows="4"
                  />
                </div>
                
                <div className="flex justify-end gap-3">
                  <button
                    onClick={() => setShowReviewModal(false)}
                    className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSubmitReview}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Submit Review
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProviderBookings;