// src/modules/providers/pages/ProviderPayouts.jsx
import React, { useState } from 'react';
import { 
  CreditCard, 
  Wallet, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  DollarSign,
  Calendar,
  Smartphone,
  ChevronRight,
  Plus,
  Download,
  Filter
} from 'lucide-react';
import { FaMoneyBill } from 'react-icons/fa';
import './ProviderPayouts.css';


const ProviderPayouts = () => {
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('bank');
  const [activeTab, setActiveTab] = useState('withdraw');

  const payoutMethods = [
    { id: 1, type: 'bank', name: 'Guaranty Trust Bank', account: '0123456789', default: true },
    { id: 2, type: 'bank', name: 'Access Bank', account: '9876543210', default: false },
    { id: 3, type: 'mobile', name: 'OPay', phone: '08123456789', default: false },
  ];

  const payoutHistory = [
    {
      id: 1,
      amount: 50000,
      method: 'Bank Transfer',
      status: 'completed',
      date: '2024-01-15',
      transactionId: 'TXN-001234',
      fee: 100
    },
    {
      id: 2,
      amount: 35000,
      method: 'OPay',
      status: 'processing',
      date: '2024-01-14',
      transactionId: 'TXN-001233',
      fee: 50
    },
    {
      id: 3,
      amount: 75000,
      method: 'Bank Transfer',
      status: 'failed',
      date: '2024-01-10',
      transactionId: 'TXN-001232',
      fee: 100
    },
  ];

  const walletBalance = {
    available: 245000,
    pending: 45000,
    minWithdrawal: 5000,
    processingFee: 100
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    if (amount >= walletBalance.minWithdrawal && amount <= walletBalance.available) {
      alert(`Withdrawal request for ₦${amount.toLocaleString()} submitted!`);
      setWithdrawAmount('');
    } else if (amount < walletBalance.minWithdrawal) {
      alert(`Minimum withdrawal amount is ₦${walletBalance.minWithdrawal.toLocaleString()}`);
    } else {
      alert('Insufficient balance');
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'processing': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'completed': return <CheckCircle size={16} />;
      case 'processing': return <Clock size={16} />;
      case 'failed': return <AlertCircle size={16} />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Payouts & Withdrawals</h1>
          <p className="text-gray-600">Withdraw your earnings to your bank account or mobile wallet</p>
        </div>
        
        <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <Download size={20} />
          <span>Download Statement</span>
        </button>
      </div>

      {/* Wallet Balance Card */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-2xl p-8">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-blue-100">Available Balance</p>
            <p className="text-4xl font-bold mt-2">₦{walletBalance.available.toLocaleString()}</p>
            <div className="flex items-center space-x-4 mt-4">
              <div className="flex items-center space-x-2">
                <Clock size={16} className="text-blue-200" />
                <span className="text-blue-200">Pending: ₦{walletBalance.pending.toLocaleString()}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Wallet size={16} className="text-blue-200" />
                <span className="text-blue-200">Min: ₦{walletBalance.minWithdrawal.toLocaleString()}</span>
              </div>
            </div>
          </div>
          <Wallet size={48} className="text-blue-200" />
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8">
          {['withdraw', 'history', 'methods'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-2 px-1 font-medium text-sm capitalize ${
                activeTab === tab
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>

      {/* Withdraw Section */}
      {activeTab === 'withdraw' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="text-lg font-semibold mb-4">Withdrawal Amount</h3>
              <div className="space-y-4">
                <div className="relative">
                  <DollarSign className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={24} />
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full pl-12 pr-4 py-4 text-2xl border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                
                <div className="grid grid-cols-4 gap-2">
                  {[5000, 10000, 25000, 50000].map((amount) => (
                    <button
                      key={amount}
                      onClick={() => setWithdrawAmount(amount.toString())}
                      className="py-3 bg-gray-100 hover:bg-gray-200 rounded-lg text-center"
                    >
                      ₦{amount.toLocaleString()}
                    </button>
                  ))}
                </div>
                
                <div className="pt-4 border-t border-gray-200 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Available Balance</span>
                    <span className="font-medium">₦{walletBalance.available.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Processing Fee</span>
                    <span className="text-red-600">-₦{walletBalance.processingFee.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold pt-2 border-t">
                    <span>You'll Receive</span>
                    <span className="text-green-600">
                      ₦{withdrawAmount ? (parseFloat(withdrawAmount) - walletBalance.processingFee).toLocaleString() : '0'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Payout Method</h3>
                <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-800">
                  <Plus size={16} />
                  <span>Add New Method</span>
                </button>
              </div>
              
              <div className="space-y-3">
                {payoutMethods.map((method) => (
                  <div
                    key={method.id}
                    onClick={() => setSelectedMethod(method.type)}
                    className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                      selectedMethod === method.type
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                        method.type === 'bank' ? 'bg-blue-100' : 'bg-green-100'
                      }`}>
                        {method.type === 'bank' ? (
                          <DollarSign className="text-blue-600" size={24} />
                        ) : (
                          <Smartphone className="text-green-600" size={24} />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{method.name}</p>
                        <p className="text-sm text-gray-600">
                          {method.type === 'bank' ? `Account: ${method.account}` : `Phone: ${method.phone}`}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      {method.default && (
                        <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                          Default
                        </span>
                      )}
                      <ChevronRight className="text-gray-400" size={20} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="text-lg font-semibold mb-4">Withdrawal Summary</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Amount</span>
                  <span className="font-medium">₦{withdrawAmount || '0'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Processing Fee</span>
                  <span className="text-red-600">-₦{walletBalance.processingFee}</span>
                </div>
                <div className="pt-3 border-t border-gray-200">
                  <div className="flex justify-between font-bold">
                    <span>You'll Receive</span>
                    <span className="text-green-600">
                      ₦{withdrawAmount ? (parseFloat(withdrawAmount) - walletBalance.processingFee).toLocaleString() : '0'}
                    </span>
                  </div>
                </div>
                
                <button
                  onClick={handleWithdraw}
                  disabled={!withdrawAmount || parseFloat(withdrawAmount) < walletBalance.minWithdrawal}
                  className={`w-full mt-6 py-3 rounded-lg font-medium ${
                    withdrawAmount && parseFloat(withdrawAmount) >= walletBalance.minWithdrawal
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }`}
                >
                  Withdraw Now
                </button>
                
                <p className="text-xs text-gray-500 text-center mt-2">
                  Processing time: 1-3 business days
                </p>
              </div>
            </div>
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
              <AlertCircle className="text-yellow-600 mb-2" size={24} />
              <h4 className="font-semibold text-yellow-800">Important Notes</h4>
              <ul className="mt-2 space-y-1 text-sm text-yellow-700">
                <li>• Minimum withdrawal: ₦{walletBalance.minWithdrawal.toLocaleString()}</li>
                <li>• Processing fee: ₦{walletBalance.processingFee} per transaction</li>
                <li>• Withdrawals processed within 1-3 business days</li>
                <li>• Weekend withdrawals may be delayed until Monday</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Payout History */}
      {activeTab === 'history' && (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Payout History</h3>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  placeholder="Search transactions..."
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button className="flex items-center space-x-2 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200">
                  <Filter size={20} />
                  <span>Filter</span>
                </button>
              </div>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="py-3 px-6 text-left text-sm font-medium text-gray-700">Date</th>
                  <th className="py-3 px-6 text-left text-sm font-medium text-gray-700">Transaction ID</th>
                  <th className="py-3 px-6 text-left text-sm font-medium text-gray-700">Amount</th>
                  <th className="py-3 px-6 text-left text-sm font-medium text-gray-700">Method</th>
                  <th className="py-3 px-6 text-left text-sm font-medium text-gray-700">Fee</th>
                  <th className="py-3 px-6 text-left text-sm font-medium text-gray-700">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {payoutHistory.map((payout) => (
                  <tr key={payout.id} className="hover:bg-gray-50">
                    <td className="py-4 px-6">
                      <div className="flex items-center space-x-2">
                        <Calendar size={16} className="text-gray-400" />
                        <span>{payout.date}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 font-mono text-sm">{payout.transactionId}</td>
                    <td className="py-4 px-6">
                      <p className="font-bold text-green-600">₦{payout.amount.toLocaleString()}</p>
                    </td>
                    <td className="py-4 px-6">
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100">
                        {payout.method}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <p className="text-red-600">-₦{payout.fee}</p>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${getStatusColor(payout.status)}`}>
                        {getStatusIcon(payout.status)}
                        <span className="ml-1 capitalize">{payout.status}</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Payout Methods */}
      {activeTab === 'methods' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold">Your Payout Methods</h3>
              <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <Plus size={20} />
                <span>Add New Method</span>
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {payoutMethods.map((method) => (
                <div key={method.id} className="border border-gray-200 rounded-xl p-6 hover:border-blue-500 transition-colors">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center space-x-3">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                        method.type === 'bank' ? 'bg-blue-100' : 'bg-green-100'
                      }`}>
                        {method.type === 'bank' ? (
                          <DollarSign className="text-blue-600" size={24} />
                        ) : (
                          <Smartphone className="text-green-600" size={24} />
                        )}
                      </div>
                      <div>
                        <p className="font-bold">{method.name}</p>
                        <p className="text-sm text-gray-600">
                          {method.type === 'bank' ? 'Bank Account' : 'Mobile Wallet'}
                        </p>
                      </div>
                    </div>
                    {method.default && (
                      <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                        Default
                      </span>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-gray-600">
                        {method.type === 'bank' ? 'Account Number' : 'Phone Number'}
                      </p>
                      <p className="font-mono text-lg">{method.type === 'bank' ? method.account : method.phone}</p>
                    </div>
                    
                    <div className="flex space-x-2 pt-4">
                      <button className="flex-1 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100">
                        Make Default
                      </button>
                      <button className="flex-1 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100">
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h4 className="font-semibold text-blue-800 mb-2">Payout Method Guidelines</h4>
            <ul className="space-y-2 text-sm text-blue-700">
              <li>• You can add multiple bank accounts and mobile wallets</li>
              <li>• One method must be set as default for automatic withdrawals</li>
              <li>• Bank transfers may take 1-3 business days to process</li>
              <li>• Mobile wallet transfers are usually instant</li>
              <li>• Ensure account details are correct to avoid failed transfers</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProviderPayouts;