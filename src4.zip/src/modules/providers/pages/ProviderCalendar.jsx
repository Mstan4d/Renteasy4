// src/modules/providers/pages/ProviderCalendar.jsx
import React, { useState } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Clock, MapPin, User, CheckCircle, AlertCircle } from 'lucide-react';
import './ProviderCalendar.css';

const ProviderCalendar = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState('month'); // 'month', 'week', 'day'

  const bookings = [
    {
      id: 1,
      title: 'Deep Cleaning',
      client: 'John Doe',
      date: '2024-01-15',
      time: '10:00 AM - 2:00 PM',
      location: 'Lagos Island',
      status: 'confirmed',
      color: 'bg-blue-100 border-blue-300'
    },
    {
      id: 2,
      title: 'Painting Service',
      client: 'Jane Smith',
      date: '2024-01-16',
      time: '9:00 AM - 5:00 PM',
      location: 'Victoria Island',
      status: 'pending',
      color: 'bg-yellow-100 border-yellow-300'
    },
    {
      id: 3,
      title: 'Plumbing Repair',
      client: 'Mike Johnson',
      date: '2024-01-17',
      time: '2:00 PM - 4:00 PM',
      location: 'Lekki Phase 1',
      status: 'confirmed',
      color: 'bg-green-100 border-green-300'
    },
  ];

  const navigateMonth = (direction) => {
    const newDate = new Date(currentDate);
    if (direction === 'prev') {
      newDate.setMonth(newDate.getMonth() - 1);
    } else {
      newDate.setMonth(newDate.getMonth() + 1);
    }
    setCurrentDate(newDate);
  };

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    
    const days = [];
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }
    
    return days;
  };

  const days = getDaysInMonth(currentDate);
  const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Service Calendar</h1>
          <p className="text-gray-600">Manage your bookings and availability</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => navigateMonth('prev')}
              className="p-2 hover:bg-gray-100 rounded-lg"
            >
              <ChevronLeft size={20} />
            </button>
            <h2 className="text-lg font-semibold">
              {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
            </h2>
            <button
              onClick={() => navigateMonth('next')}
              className="p-2 hover:bg-gray-100 rounded-lg"
            >
              <ChevronRight size={20} />
            </button>
          </div>
          
          <div className="flex space-x-2">
            {['month', 'week', 'day'].map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`px-4 py-2 rounded-lg capitalize ${
                  view === v 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {v}
              </button>
            ))}
          </div>
          
          <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
            Set Availability
          </button>
        </div>
      </div>

      {/* Calendar View */}
      {view === 'month' && (
        <>
          <div className="bg-white rounded-xl border border-gray-200">
            {/* Week Days Header */}
            <div className="grid grid-cols-7 border-b border-gray-200">
              {weekDays.map((day) => (
                <div key={day} className="p-4 text-center font-semibold text-gray-700">
                  {day}
                </div>
              ))}
            </div>

            {/* Days Grid */}
            <div className="grid grid-cols-7">
              {days.map((day, index) => {
                const dayBookings = bookings.filter(
                  booking => booking.date === day.toISOString().split('T')[0]
                );
                
                const isToday = day.toDateString() === new Date().toDateString();
                
                return (
                  <div
                    key={index}
                    className={`min-h-32 border border-gray-100 p-2 ${
                      isToday ? 'bg-blue-50' : ''
                    }`}
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className={`font-medium ${
                        isToday 
                          ? 'bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center'
                          : 'text-gray-700'
                      }`}>
                        {day.getDate()}
                      </span>
                      {dayBookings.length > 0 && (
                        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                          {dayBookings.length} booking{dayBookings.length > 1 ? 's' : ''}
                        </span>
                      )}
                    </div>
                    
                    <div className="space-y-1">
                      {dayBookings.map((booking) => (
                        <div
                          key={booking.id}
                          className={`p-2 rounded border ${booking.color} text-xs`}
                        >
                          <p className="font-medium truncate">{booking.title}</p>
                          <p className="text-gray-600 truncate">{booking.time}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}

      {/* Upcoming Bookings */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Upcoming Bookings</h3>
          <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
            View All
          </button>
        </div>
        
        <div className="space-y-4">
          {bookings.map((booking) => (
            <div key={booking.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${booking.color}`}>
                  <CalendarIcon className={booking.status === 'confirmed' ? 'text-green-600' : 'text-yellow-600'} size={24} />
                </div>
                <div>
                  <h4 className="font-bold">{booking.title}</h4>
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <span className="flex items-center space-x-1">
                      <User size={14} />
                      <span>{booking.client}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Clock size={14} />
                      <span>{booking.time}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <MapPin size={14} />
                      <span>{booking.location}</span>
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <span className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm ${
                  booking.status === 'confirmed' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {booking.status === 'confirmed' ? <CheckCircle size={14} /> : <AlertCircle size={14} />}
                  <span className="capitalize">{booking.status}</span>
                </span>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600">Bookings This Month</p>
              <p className="text-2xl font-bold">18</p>
            </div>
            <CalendarIcon className="text-blue-600" size={24} />
          </div>
          <p className="text-sm text-green-600 mt-2">↑ 5 from last month</p>
        </div>
        
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600">Available Days</p>
              <p className="text-2xl font-bold">24/31</p>
            </div>
            <CheckCircle className="text-green-600" size={24} />
          </div>
          <p className="text-sm text-green-600 mt-2">Fully booked for 7 days</p>
        </div>
        
        <div className="bg-white p-6 rounded-xl border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600">Next Available Slot</p>
              <p className="text-2xl font-bold">Jan 18</p>
            </div>
            <Clock className="text-purple-600" size={24} />
          </div>
          <p className="text-sm text-gray-600 mt-2">2:00 PM - 4:00 PM</p>
        </div>
      </div>
    </div>
  );
};

export default ProviderCalendar;