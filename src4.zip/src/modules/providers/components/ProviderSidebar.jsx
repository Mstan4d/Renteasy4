
import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  FaTachometerAlt, FaUser, FaClipboardList, FaCalendarAlt, 
  FaMoneyBill, FaWallet, FaCog, FaBell, FaStar, FaShieldAlt,
  FaChartLine, FaBullhorn, FaImage, FaMapMarkerAlt, FaFileAlt,
  FaComments, FaHandshake, FaCheckCircle, FaTools, FaBars, FaTimes,
  FaHome, FaDollarSign, FaCreditCard, FaHistory, FaChartBar,
  FaUserCheck, FaFolderOpen, FaTags, FaClock, FaPercentage
} from 'react-icons/fa';

const ProviderSidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const navigate = useNavigate();

  const navItems = [
    // Dashboard & Overview
    { path: '/dashboard/provider/dashboard', label: 'Dashboard', icon: <FaTachometerAlt /> },
    
    // Profile & Public Presence
    { path: '/dashboard/provider/profile', label: 'Profile', icon: <FaUser /> },
    { path: '/dashboard/provider/portfolio', label: 'Portfolio', icon: <FaImage /> },
    
    // Leads & Bookings
    { path: '/dashboard/provider/leads', label: 'Leads', icon: <FaClipboardList /> },
    { path: '/dashboard/provider/bookings', label: 'Bookings', icon: <FaCalendarAlt /> },
    { path: '/dashboard/provider/calendar', label: 'Calendar', icon: <FaClock /> },
    
    // Finance & Payments
    { path: '/dashboard/provider/earnings', label: 'Earnings', icon: <FaMoneyBill /> },
    { path: '/dashboard/provider/payouts', label: 'Payouts', icon: <FaDollarSign /> },
    { path: '/dashboard/provider/wallet', label: 'Wallet', icon: <FaWallet /> },
    { path: '/dashboard/provider/transactions', label: 'Transactions', icon: <FaHistory /> },
    { path: '/dashboard/provider/payment-methods', label: 'Payment Methods', icon: <FaCreditCard /> },
    
    // Service Management
    { path: '/dashboard/provider/services', label: 'Services', icon: <FaTools /> },
    { path: '/dashboard/provider/post-service', label: 'Post Service', icon: <FaFolderOpen /> },
    { path: '/dashboard/provider/service-categories', label: 'Categories', icon: <FaTags /> },
    { path: '/dashboard/provider/pricing', label: 'Pricing', icon: <FaPercentage /> },
    
    // Analytics & Performance
    { path: '/dashboard/provider/analytics', label: 'Analytics', icon: <FaChartLine /> },
    { path: '/dashboard/provider/performance', label: 'Performance', icon: <FaChartBar /> },
    
    // Verification & Compliance
    { path: '/dashboard/provider/verify', label: 'Get Verified', icon: <FaShieldAlt /> },
    { path: '/dashboard/provider/verification-status', label: 'Verification Status', icon: <FaUserCheck /> },
    { path: '/dashboard/provider/compliance', label: 'Compliance', icon: <FaCheckCircle /> },
    
    // Boost & Marketing
    { path: '/dashboard/provider/boost', label: 'Boost Profile', icon: <FaBullhorn /> },
    { path: '/dashboard/provider/boost-history', label: 'Boost History', icon: <FaHistory /> },
    { path: '/dashboard/provider/referral', label: 'Referral Program', icon: <FaHandshake /> },
    
    // Availability & Location
    { path: '/dashboard/provider/availability', label: 'Availability', icon: <FaCalendarAlt /> },
    { path: '/dashboard/provider/location-setup', label: 'Service Area', icon: <FaMapMarkerAlt /> },
    
    // Documents
    { path: '/dashboard/provider/documents', label: 'Documents', icon: <FaFileAlt /> },
    
    
    // Communication
    { path: '/dashboard/provider/messages', label: 'Messages', icon: <FaComments /> },
    { path: '/dashboard/provider/notifications', label: 'Notifications', icon: <FaBell /> },


// Support & Settings
    { path: '/dashboard/provider/support', label: 'Support', icon: <FaHandshake /> },
    { path: '/dashboard/provider/settings', label: 'Settings', icon: <FaCog /> },
    
    // Subscription & Billing
    { path: '/dashboard/provider/subscription', label: 'Subscription', icon: <FaCreditCard /> },
    { path: '/dashboard/provider/billing', label: 'Billing', icon: <FaDollarSign /> },
  ];

  const handleLogout = () => {
    localStorage.removeItem('renteasy_user');
    localStorage.removeItem('renteasy_token');
    navigate('/login');
  };

  return (
    <div className={`provider-sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-header">
        {!isCollapsed && <h3 className="provider-logo">RentEasy Provider</h3>}
        
        <button 
          className="sidebar-toggle"
          onClick={() => setIsCollapsed(!isCollapsed)}
        >
          {isCollapsed ? <FaBars /> : <FaTimes />}
        </button>
      </div>
  
      <nav className="sidebar-nav">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `nav-item ${isActive ? 'active' : ''}`
            }
          >
            <span className="nav-icon">{item.icon}</span>
            {!isCollapsed && (
              <span className="nav-label">{item.label}</span>
            )}
          </NavLink>
        ))}
      </nav>
      
      <div className="sidebar-footer">
        <div className="provider-info">
          {!isCollapsed && (
            <>
              <div className="provider-avatar">
                <span>P</span>
              </div>
              <div className="provider-details">
  <h4>Service Provider</h4>
  <p className="provider-email">
    {
      JSON.parse(
        localStorage.getItem('renteasy_user') || '{}'
      )?.email || 'provider@example.com'
    }
  </p>
</div>
            </>
          )}
        </div>
        <button 
          className="logout-btn"
          onClick={handleLogout}
          title={isCollapsed ? "Logout" : ""}
        >
          <span className="logout-icon">🚪</span>
          {!isCollapsed && <span>Logout</span>}
        </button>
      </div>
    </div>
  );
};

export default ProviderSidebar;